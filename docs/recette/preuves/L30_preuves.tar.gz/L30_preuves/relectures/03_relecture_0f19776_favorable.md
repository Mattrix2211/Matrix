RELECTURE INDÉPENDANTE L30 — SHA 0f19776 (résumé du rapport remis)
VERDICT : FAVORABLE, aucun bloquant. Corrections de 71c7c7d confirmées par sonde (auteur, destinataire, section, secteur, service supprimés ; compte sans profil ; synthèses dégradées : aucun 500 ; concurrence PostgreSQL : un partage actif par émetteur, une seule trace de révocation ; rang de révocation ; génération en 12 requêtes pour 0 comme pour 20 marins).
Important non bloquant : la page de partage relisait le contenu figé de la synthèse pour chaque partage (47, 53 puis 71 requêtes pour 0, 3 et 12 partages).
Mineurs : double clic sur « Révoquer » donnant 404 au second clic de l'auteur ; ligne partagée avec lien mort vers un objet interdit ; équivalence de partages inertes.
Remarque de conception : le formulaire de partage liste les marins actifs du bâtiment (cohérent avec « partage vers un marin »).
Conformes : cloisonnement, élévations de privilège, fuites indirectes, contenu antérieur, équipage à terre, migration org.0019 sur les deux moteurs, socle L06, tests modifiés sans affaiblissement.
Suite donnée : les suites complètes sur ce SHA ont révélé deux tests de vocabulaire (« périmètre » interdit dans l'interface) ; libellés corrigés, contenu figé non relu par partage, second clic neutre, ligne partagée sans lien.
