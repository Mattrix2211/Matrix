RELECTURE INDÉPENDANTE L30 — SHA 71c7c7d (résumé du rapport remis)
VERDICT : À CORRIGER. Les huit corrections de la première relecture sont confirmées par sonde réelle (concurrence PostgreSQL, rang de révocation, historique, message unique, génération, réglages, SET_NULL, second émetteur).
Bloquant B1 : la page de partage plante (erreur 500) dès que l'auteur d'un partage a été supprimé (filtre de gabarit sur un auteur NULL) : le bouton « Révoquer » devient inatteignable.
Mineurs : M1 message de révocation trompeur quand un partage de rang supérieur subsiste ; M2 génération encore en coût par marin ; M3 compte sans profil désigné comme destinataire : exception non interceptée.
Conformes : cloisonnement, accès directs, 404 indiscernables, contenu antérieur, PDF, notifications sans contenu, équipage à terre, blocs maintenance/tickets/listes/annonces/demandes, migration, socle L06.
Suite donnée : gabarit robuste à l'auteur supprimé (test), message de révocation fidèle, ObjectDoesNotExist, unité du marin dérivée du profil chargé.
