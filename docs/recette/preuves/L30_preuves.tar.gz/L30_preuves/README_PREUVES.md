# Lot L30 — archive des preuves et journaux

Données fictives uniquement ; aucun secret (recherche du mot de passe de la base temporaire, de clés et de jetons dans tous les fichiers : rien). Les variables d'environnement nécessaires (`DJANGO_DEBUG=1`, clé de test, accès à la base PostgreSQL de test) sont fournies à l'exécution et ne sont pas consignées.

## 1. Références Git
| Référence | SHA | Rôle |
|---|---|---|
| L06 clos (point de départ de la branche) | `58691cc` | dernier code L06 `e94e186`, 4 174 tests recensés par moteur |
| Clôture documentaire L06 | `1c57c89` | statut, réserves transférées (PLAN §9, L06 §23) |
| Code intermédiaire relu | `04b817e`, `71c7c7d`, `0f19776` | relectures 1 à 3 |
| **Code final testé et relu** | `3761fe9` | suites complètes SQLite et PostgreSQL, quatrième relecture FAVORABLE |
Les commits suivants de la branche `claude/l30-passations-cloisonnement-v11` ne modifient que la documentation et cette archive (démontré par `git diff --name-only 3761fe9..HEAD`).

## 2. Environnement
Python 3.13, Django 5.2, SQLite 3, PostgreSQL 16.15 (grappe temporaire locale), Linux ; `manage.py test --parallel 4 --noinput`.

## 3. Commandes
- Suites complètes : `python manage.py test --parallel 4 --noinput` sur un instantané `git archive` du SHA exact, sans base (SQLite) puis avec `DB_HOST/DB_PORT/DB_USER/DB_NAME/DB_PASSWORD` (PostgreSQL).
- Migration `org.0019_partage_passation` : `migration/rejouer_l30.sh sqlite|pg` — base créée par le code `58691cc`, peuplée de comptes et de synthèses fictifs (`peupler_l30.py`), sauvegardée (copie de fichier ou `pg_dump -Fc`), `migrate` vers le code L30, `makemigrations --check`, retour arrière `migrate org 0018`, restauration (`pg_restore`), comparaison (`etat_l30.py`, `partage_l30.py`).

## 4. Résultats complets
| Exécution | Moteur | Tests | Résultat | Ignorés | Journal |
|---|---|---|---|---|---|
| Référence L06 `e94e186` | SQLite / PostgreSQL 16 | 4174 / 4174 | OK / OK | 22 / 22 | `logs/e94e186_reference_L06_*.log` |
| Intermédiaire `0f19776` | SQLite / PostgreSQL 16 | 4212 / 4212 | **2 échecs** de vocabulaire (« périmètre » dans l'interface) / idem | 23 / 22 | `logs/0f19776_intermediaire_*` |
| **Final `3761fe9`** | SQLite / PostgreSQL 16 | **4213 / 4213** | **OK / OK** | 23 / 22 | `logs/3761fe9_final_*.log` |
Écart avec la référence L06 : +39 tests ; aucun test supprimé. Le scénario de concurrence du partage ne s'exécute que sur PostgreSQL (23 ignorés sur SQLite, 22 sur PostgreSQL).

## 5. Migration (`migration/`)
`rejouer_org0019_sqlite.log`, `rejouer_org0019_pg.log` : mise à niveau `org.0019` (table neuve `PartagePassation`), aucune synthèse existante modifiée (le contenu antérieur reste identique, lisible du commandement seul), `makemigrations --check` sans écart, retour arrière à `org.0018`, restauration depuis la sauvegarde : données identiques à l'état initial sur les deux moteurs.

## 6. Relectures indépendantes (`relectures/`)
Quatre relectures : `04b817e` (à corriger), `71c7c7d` (à corriger), `0f19776` (favorable), **`3761fe9` : favorable, aucun bloquant, aucun important**. Chaque correction du code a été suivie d'une nouvelle relecture ; la dernière relecture favorable et les dernières suites complètes portent exactement sur le même code (`3761fe9`).
