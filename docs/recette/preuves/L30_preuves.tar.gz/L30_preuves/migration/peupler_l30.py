"""Peuple une base au schéma L06 final : bâtiment, marins, synthèse de passation (contenu version 1 puis une synthèse vide)."""
import os, sys, django
sys.path.insert(0, os.getcwd()); os.environ.setdefault("DJANGO_SETTINGS_MODULE", "matrix.settings"); django.setup()
from django.contrib.auth import get_user_model
from accounts.models import UserProfile
from org.models import Service, Ship, SynthesePassation
User = get_user_model()
navire = Ship.objects.create(name="Fictif", code="FIC", double_equipage=True, equipage_a_bord="A")
service = Service.objects.create(ship=navire, name="Énergie")
for nom, role in (("cdt", "COMMANDANT"), ("chef", "CHEF_SERVICE"), ("marin", "EQUIPIER")):
    u = User.objects.create_user(nom, password="fictif-123")
    UserProfile.objects.filter(user=u).update(role=role, ship=navire, service=service if nom != "cdt" else None, equipage="A")
ancien = {"blocs": [{"cle": "taches", "titre": "Tâches", "total": 1, "vide": "", "groupes": [{"titre": "À faire", "total": 1, "plus": 0, "lignes": [{"titre": "TACHE-ANCIENNE", "detail": "", "url": "/", "etat": ""}]}]}]}
SynthesePassation.objects.create(ship=navire, equipage_sortant="B", equipage_montant="A", contenu=ancien)
SynthesePassation.objects.create(ship=navire, equipage_sortant="A", equipage_montant="B", contenu={})
print("peuplé : 1 bâtiment, 3 marins, 2 synthèses (contenu figé avant L30)")
