import os, sys, json, django
sys.path.insert(0, os.getcwd()); os.environ.setdefault("DJANGO_SETTINGS_MODULE", "matrix.settings"); django.setup()
from org.models import SynthesePassation
print(json.dumps({"syntheses": [(s.equipage_sortant, s.equipage_montant, s.contenu) for s in SynthesePassation.objects.order_by("pk")]}, ensure_ascii=False, sort_keys=True))
