#!/bin/bash
# Rejoue org.0019 (partage de passation) : base créée par le code L06 final (58691cc), peuplée, sauvegardée, mise à niveau vers L30,
# retour arrière à org.0018, restauration. Usage : rejouer_l30.sh sqlite|pg ; données fictives uniquement.
export DJANGO_DEBUG=1 DJANGO_SECRET_KEY=x MATRIX_MEDIA_ROOT=/tmp/l30m_proof
MOTEUR=$1; ANCIEN=/tmp/l06/base58691cc; NOUVEAU=/home/user/wt_l30; SORTIE=/tmp/l06/proof_l30; mkdir -p $SORTIE
if [ "$MOTEUR" = sqlite ]; then
  export MATRIX_SQLITE_PATH=$SORTIE/base.sqlite3; rm -f $SORTIE/base.sqlite3
else
  unset MATRIX_SQLITE_PATH; export DB_HOST=127.0.0.1 DB_PORT=5549 DB_USER=matrix DB_PASSWORD=$(cat /var/tmp/pg_l06/pw) PGPASSWORD=$(cat /var/tmp/pg_l06/pw) DB_NAME=mig_l30
  P="psql -h 127.0.0.1 -p 5549 -U matrix -d postgres -qAt -c"; $P "DROP DATABASE IF EXISTS mig_l30" 2>/dev/null; $P "CREATE DATABASE mig_l30"
fi
echo "== état initial : code 58691cc (L06 clos), synthèses de passation fictives"
(cd $ANCIEN && python3 manage.py migrate -v0 >/dev/null 2>&1 && python3 /tmp/l06/peupler_l30.py 2>&1 | tail -1 && python3 /tmp/l06/etat_l30.py > $SORTIE/${MOTEUR}_avant.json 2>/dev/null; cat $SORTIE/${MOTEUR}_avant.json)
echo "== sauvegarde avant mise à niveau"
if [ "$MOTEUR" = sqlite ]; then cp $SORTIE/base.sqlite3 $SORTIE/sauvegarde.sqlite3; else pg_dump -h 127.0.0.1 -p 5549 -U matrix -Fc mig_l30 > $SORTIE/sauvegarde.dump; fi
echo "== mise à niveau vers le code L30 (org.0019)"
(cd $NOUVEAU && python3 manage.py migrate -v1 2>/dev/null | grep -E "Applying org"; python3 /tmp/l06/etat_l30.py > $SORTIE/${MOTEUR}_apres.json 2>/dev/null; cat $SORTIE/${MOTEUR}_apres.json; python3 manage.py makemigrations --check --dry-run 2>/dev/null | tail -1; python3 /tmp/l06/partage_l30.py 2>&1 | tail -2)
echo "== retour arrière de org.0019 (migrate org 0018)"
(cd $NOUVEAU && python3 manage.py migrate org 0018 -v1 2>/dev/null | grep -E "Unapplying"; cd $ANCIEN && python3 /tmp/l06/etat_l30.py 2>/dev/null)
echo "== restauration depuis la sauvegarde"
if [ "$MOTEUR" = sqlite ]; then cp $SORTIE/sauvegarde.sqlite3 $SORTIE/base.sqlite3; else $P "DROP DATABASE mig_l30"; $P "CREATE DATABASE mig_l30"; pg_restore -h 127.0.0.1 -p 5549 -U matrix -d mig_l30 $SORTIE/sauvegarde.dump; fi
(cd $ANCIEN && python3 /tmp/l06/etat_l30.py > $SORTIE/${MOTEUR}_restaure.json 2>/dev/null)
cmp $SORTIE/${MOTEUR}_avant.json $SORTIE/${MOTEUR}_restaure.json && echo "restauration : données identiques à l'état initial"
[ "$MOTEUR" = pg ] && $P "DROP DATABASE mig_l30"
echo "== fin"
