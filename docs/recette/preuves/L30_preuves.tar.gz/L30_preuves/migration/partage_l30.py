"""Après mise à niveau : le contenu ancien reste lisible du commandement seul ; un partage se crée et se révoque."""
import os, sys, django
sys.path.insert(0, os.getcwd()); os.environ.setdefault("DJANGO_SETTINGS_MODULE", "matrix.settings"); django.setup()
from django.contrib.auth import get_user_model
from dashboard.passation_perimetre import contenu_visible
from org.models import PartagePassation, SynthesePassation
User = get_user_model()
s = SynthesePassation.objects.order_by("pk").first()
lus = lambda nom: sum(b["total"] for b in contenu_visible(User.objects.get(username=nom), s)["blocs"])
print("contenu ancien : commandant", lus("cdt"), "lignes ; chef", lus("chef"), "; marin", lus("marin"), "; partages", PartagePassation.objects.count())
