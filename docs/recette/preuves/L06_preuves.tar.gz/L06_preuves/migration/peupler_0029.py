"""Peuple une base au schéma de la version initiale de 0029 (données fictives)."""
import os, sys, django
sys.path.insert(0, os.getcwd()); os.environ.setdefault("DJANGO_SETTINGS_MODULE", "matrix.settings"); django.setup()
from datetime import timedelta
from django.contrib.auth import get_user_model
from django.utils import timezone
from accounts.models import CompteurConnexion, DemandeReinitialisation, OperateurRecuperation
User = get_user_model()
now = timezone.now()
marin = User.objects.create_user("marin", password="fictif-1"); autre = User.objects.create_user("autre", password="fictif-2")
DemandeReinitialisation.objects.create(user=marin, statut="BLOQUEE", code_initiateur="x", expire_le=now, essais=7)
DemandeReinitialisation.objects.create(user=autre, statut="ACTIVE", code_initiateur="y", expire_le=now + timedelta(minutes=20), essais=2)
OperateurRecuperation.objects.create(nom="Alice", identifiant_systeme="sys-a", phrase="x")
OperateurRecuperation.objects.create(nom="Alice", identifiant_systeme="sys-b", phrase="x")
CompteurConnexion.objects.create(identifiant="marin", source="10.0.0.1", essais=3, derniere_activite=now)
for i in range(50):
    CompteurConnexion.objects.create(identifiant=f"invente-{i}", source="10.0.0.1", essais=1, derniere_activite=now)
print("peuplé : 2 comptes, 2 demandes, 2 opérateurs homonymes, 51 compteurs")
