import os, sys, json, django
sys.path.insert(0, os.getcwd()); os.environ.setdefault("DJANGO_SETTINGS_MODULE", "matrix.settings"); django.setup()
from django.db import connection
from accounts.models import CompteurConnexion, DemandeReinitialisation, OperateurRecuperation
cols = [c.name for c in connection.introspection.get_table_description(connection.cursor(), "accounts_demandereinitialisation")]
print(json.dumps({
    "demandes": sorted((d.user.username, d.statut) for d in DemandeReinitialisation.objects.select_related("user")),
    "operateurs": sorted(OperateurRecuperation.objects.values_list("nom", "identifiant_systeme")),
    "compteurs": sorted(CompteurConnexion.objects.values_list("identifiant", flat=True)),
    "colonne_essais": "essais" in cols,
}, ensure_ascii=False, sort_keys=True))
