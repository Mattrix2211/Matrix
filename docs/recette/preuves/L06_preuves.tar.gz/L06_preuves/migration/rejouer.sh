#!/bin/bash
# Rejoue migration, retour arrière et restauration sur données fictives. Usage : rejouer.sh sqlite|pg
export DJANGO_DEBUG=1 DJANGO_SECRET_KEY=x MATRIX_MEDIA_ROOT=/tmp/l06m_proof
MOTEUR=$1; cd /tmp/l06
resume() { python3 -c "
import json;a=json.load(open('/tmp/l06/proof/${MOTEUR}_avant.json'));b=json.load(open('/tmp/l06/proof/${MOTEUR}_apres.json'))
print({n:(a['profils'][n][:1],b['profils'][n][:2]+b['profils'][n][3:]) for n in a['profils'] if a['profils'][n][:1]!=b['profils'][n][:1]},'journal',b['journal'])"; }
if [ "$MOTEUR" = sqlite ]; then
  export MATRIX_SQLITE_PATH=/tmp/l06/proof/base.sqlite3; rm -f /tmp/l06/proof/base.sqlite3
else
  unset MATRIX_SQLITE_PATH; export DB_HOST=127.0.0.1 DB_PORT=5549 DB_USER=matrix DB_PASSWORD=$(cat /var/tmp/pg_l06/pw) PGPASSWORD=$(cat /var/tmp/pg_l06/pw) DB_NAME=mig_final
  P="psql -h 127.0.0.1 -p 5549 -U matrix -d postgres -qAt -c"; $P "DROP DATABASE IF EXISTS mig_final" 2>/dev/null; $P "CREATE DATABASE mig_final"
fi
echo "== état initial (code c355310) : création et peuplement de comptes fictifs"
(cd base29 && python3 manage.py migrate -v0 >/dev/null 2>&1 && python3 /tmp/l06/peupler.py 2>/dev/null && python3 - >/dev/null 2>&1 <<'PY'
import os,sys,django
sys.path.insert(0,os.getcwd());os.environ.setdefault("DJANGO_SETTINGS_MODULE","matrix.settings");django.setup()
from accounts.models import UserProfile
p=UserProfile.objects.get(user__username="marin1"); p.role="ETAT_MAJOR"; p.fonction_coma="COMANAV"; p.save()
PY
python3 /tmp/l06/etat.py 2>/dev/null > /tmp/l06/proof/${MOTEUR}_avant.json)
echo "== sauvegarde avant migration"
if [ "$MOTEUR" = sqlite ]; then cp /tmp/l06/proof/base.sqlite3 /tmp/l06/proof/sauvegarde.sqlite3; else pg_dump -h 127.0.0.1 -p 5549 -U matrix -Fc mig_final > /tmp/l06/proof/sauvegarde.dump; fi
echo "== migration vers le code final (accounts 0024 à 0029)"
(cd /home/user/wt_l06 && python3 manage.py migrate -v1 2>/dev/null | grep -E "accounts\.00(24|25|26|27|28|29)"; python3 /tmp/l06/etat.py 2>/dev/null > /tmp/l06/proof/${MOTEUR}_apres.json; python3 /tmp/l06/etat2.py 2>/dev/null)
resume
echo "== retour arrière (migrate accounts 0023)"
(cd /home/user/wt_l06 && python3 manage.py migrate accounts 0023 -v1 2>/dev/null | grep -E "Unapplying")
(cd base29 && python3 /tmp/l06/etat.py 2>/dev/null > /tmp/l06/proof/${MOTEUR}_retour.json)
cmp /tmp/l06/proof/${MOTEUR}_avant.json /tmp/l06/proof/${MOTEUR}_retour.json && echo "retour arrière : profils identiques à l'état initial ; traces de migration conservées sous le libellé « _annulee » (jamais supprimées)"
echo "== restauration depuis la sauvegarde"
if [ "$MOTEUR" = sqlite ]; then cp /tmp/l06/proof/sauvegarde.sqlite3 /tmp/l06/proof/base.sqlite3; else $P "DROP DATABASE mig_final"; $P "CREATE DATABASE mig_final"; pg_restore -h 127.0.0.1 -p 5549 -U matrix -d mig_final /tmp/l06/proof/sauvegarde.dump; fi
(cd base29 && python3 /tmp/l06/etat.py 2>/dev/null > /tmp/l06/proof/${MOTEUR}_restaure.json)
cmp /tmp/l06/proof/${MOTEUR}_avant.json /tmp/l06/proof/${MOTEUR}_restaure.json && echo "restauration : profils identiques à l'état initial"
[ "$MOTEUR" = pg ] && $P "DROP DATABASE mig_final"
echo "== fin"
