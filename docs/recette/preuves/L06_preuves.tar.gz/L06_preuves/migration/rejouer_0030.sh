#!/bin/bash
# Rejoue la mise à niveau d'une base ayant appliqué la version initiale de 0029 (code 619e686) vers 0030 (code final), avec
# retour arrière et restauration. Usage : rejouer_0030.sh sqlite|pg ; données fictives uniquement.
export DJANGO_DEBUG=1 DJANGO_SECRET_KEY=x MATRIX_MEDIA_ROOT=/tmp/l06m_proof30
MOTEUR=$1; ANCIEN=/tmp/l06/base1cb; NOUVEAU=/home/user/wt_l06; SORTIE=/tmp/l06/proof30; mkdir -p $SORTIE
if [ "$MOTEUR" = sqlite ]; then
  export MATRIX_SQLITE_PATH=$SORTIE/base.sqlite3; rm -f $SORTIE/base.sqlite3
else
  unset MATRIX_SQLITE_PATH; export DB_HOST=127.0.0.1 DB_PORT=5549 DB_USER=matrix DB_PASSWORD=$(cat /var/tmp/pg_l06/pw) PGPASSWORD=$(cat /var/tmp/pg_l06/pw) DB_NAME=mig_0030
  P="psql -h 127.0.0.1 -p 5549 -U matrix -d postgres -qAt -c"; $P "DROP DATABASE IF EXISTS mig_0030" 2>/dev/null; $P "CREATE DATABASE mig_0030"
fi
echo "== état initial : code 619e686 (0029 dans sa version initiale), données fictives"
(cd $ANCIEN && python3 manage.py migrate -v0 >/dev/null 2>&1 && python3 /tmp/l06/peupler_0029.py 2>&1 | tail -1 && python3 /tmp/l06/etat_0030.py > $SORTIE/${MOTEUR}_avant.json 2>/dev/null; cat $SORTIE/${MOTEUR}_avant.json)
echo "== sauvegarde avant mise à niveau"
if [ "$MOTEUR" = sqlite ]; then cp $SORTIE/base.sqlite3 $SORTIE/sauvegarde.sqlite3; else pg_dump -h 127.0.0.1 -p 5549 -U matrix -Fc mig_0030 > $SORTIE/sauvegarde.dump; fi
echo "== mise à niveau vers le code final (0030)"
(cd $NOUVEAU && python3 manage.py migrate -v1 2>/dev/null | grep -E "Applying accounts"; python3 /tmp/l06/etat_0030.py > $SORTIE/${MOTEUR}_apres.json 2>/dev/null; cat $SORTIE/${MOTEUR}_apres.json; python3 manage.py makemigrations --check --dry-run 2>/dev/null | tail -1)
echo "== retour arrière de 0030 (migrate accounts 0029)"
(cd $NOUVEAU && python3 manage.py migrate accounts 0029 -v1 2>/dev/null | grep -E "Unapplying"; cd $ANCIEN && python3 /tmp/l06/etat_0030.py 2>/dev/null)
echo "== restauration depuis la sauvegarde"
if [ "$MOTEUR" = sqlite ]; then cp $SORTIE/sauvegarde.sqlite3 $SORTIE/base.sqlite3; else $P "DROP DATABASE mig_0030"; $P "CREATE DATABASE mig_0030"; pg_restore -h 127.0.0.1 -p 5549 -U matrix -d mig_0030 $SORTIE/sauvegarde.dump; fi
(cd $ANCIEN && python3 /tmp/l06/etat_0030.py > $SORTIE/${MOTEUR}_restaure.json 2>/dev/null)
cmp $SORTIE/${MOTEUR}_avant.json $SORTIE/${MOTEUR}_restaure.json && echo "restauration : données identiques à l'état initial"
[ "$MOTEUR" = pg ] && $P "DROP DATABASE mig_0030"
echo "== fin"
