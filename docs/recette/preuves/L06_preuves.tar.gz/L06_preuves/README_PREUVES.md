# Lot L06 — archive des preuves et journaux

Données fictives uniquement ; aucun secret (vérifié par recherche du mot de passe de la base temporaire, de clés et de jetons dans tous les fichiers). Les variables d'environnement nécessaires aux commandes (`DJANGO_DEBUG=1`, clé de test, accès à la base de test PostgreSQL) sont fournies à l'exécution et ne sont pas consignées.

## 1. Références Git testées
| Référence | SHA | Rôle |
|---|---|---|
| L29 validé | `c355310` | référence de comparaison |
| Rapport intermédiaire L06 | `2fa183a` | dernier code = `326387b` |
| Code intermédiaire testé et relu | `e004ee6` | cinquième relecture ; AC-15 à AC-21 non encore consolidés |
| Code intermédiaire | `e91e7e5` | suite SQLite ; sixième relecture : À CORRIGER |
| Code intermédiaire | `886075a` | corrections de la sixième relecture ; septième relecture : À CORRIGER |
| **Code final testé et relu** | `be7cb5d` | suites complètes SQLite et PostgreSQL, huitième relecture FAVORABLE |
Les commits suivants de la branche `claude/l06-autorites-technique-metier-v11` ne modifient que la documentation et cette archive (démontré par `git diff --name-only be7cb5d..HEAD` : uniquement `docs/`).

## 2. Environnement
Python 3.13.18, Django 5.2.17, SQLite 3.53.1, PostgreSQL 16.15 (grappe temporaire locale, UTF8, `fsync=off`), Linux 6.18 ; `manage.py test --parallel 4 --noinput`.

## 3. Commandes exécutées (principales)
- Suites complètes : `python manage.py test --parallel 4 --noinput`, sans base (SQLite) puis avec `DB_HOST/DB_PORT/DB_USER/DB_NAME/DB_PASSWORD` (PostgreSQL), sur chaque référence.
- Migrations : `migration/rejouer.sh sqlite|pg` — création d'une base par le code `c355310`, peuplement de comptes fictifs (`peupler.py`), sauvegarde (copie de fichier ou `pg_dump -Fc`), `migrate` vers le code final, `migrate accounts 0023` (retour arrière), restauration (`pg_restore`), comparaison des profils (`etat.py`, `etat2.py`).
- Essai de retrait du niveau 9 de l'administrateur général (non conservé dans le code) : suite complète SQLite, journal fourni (32 échecs, voir `docs/recette/L06_MIGRATION_ET_PREUVES.md` §13).

## 4. Résultats complets
| Exécution | Moteur | Tests | Résultat | Ignorés | Journal |
|---|---|---|---|---|---|
| Référence `c355310` | SQLite | 4021 | OK | 20 | `logs/c355310_reference_sqlite.log` |
| Référence `c355310` | PostgreSQL 16 | 4021 | OK | 22 | `logs/c355310_reference_postgresql.log` |
| Intermédiaire `326387b` | SQLite | 4045 | OK | 20 | `logs/326387b_intermediaire_sqlite.log` |
| Intermédiaire `326387b` | PostgreSQL 16 | 4045 | OK | 22 | `logs/326387b_intermediaire_postgresql.log` |
| Intermédiaire `e004ee6` | SQLite | 4083 | OK | 20 | `logs/e004ee6_final_sqlite.log` |
| Intermédiaire `e004ee6` | PostgreSQL 16 | 4083 | OK | 22 | `logs/e004ee6_final_postgresql.log` |
| Intermédiaire `e91e7e5` | SQLite | 4124 | OK | 20 | `logs/e91e7e5_intermediaire_sqlite.log` |
| Intermédiaire `886075a` | SQLite | 4135 | OK | 20 | `logs/886075a_intermediaire_sqlite.log` |
| Intermédiaire `886075a` | PostgreSQL 16 | 4135 | OK | 22 | `logs/886075a_intermediaire_postgresql.log` |
| **Final `be7cb5d`** | SQLite | **4139** | **OK** | 20 | `logs/be7cb5d_final_sqlite.log` |
| **Final `be7cb5d`** | PostgreSQL 16 | **4139** | **OK** | 22 | `logs/be7cb5d_final_postgresql.log` |
Écart avec la référence : +118 tests ajoutés par L06 ; aucun test supprimé, aucun ignoré en plus (mêmes 20 et 22 que la référence).

## 5. Migrations et restauration (`migration/`)
`migration_sqlite.log`, `migration_pg.log` (rejoués sur le code final) : migrations `accounts` 0024 à 0029 appliquées sur une base créée par `c355310` et peuplée de comptes fictifs (administrateurs d'unité convertis en équipier + droits techniques, administrateur général converti en indicateur, une fonction à confirmer en attente, aucune anomalie de cohérence) ; retour arrière à 0023 puis restauration depuis sauvegarde : profils identiques à l'état initial sur les deux moteurs ; les traces de migration sont conservées sous un libellé « _annulee » (ou « _non_restauree »), jamais supprimées (`*_avant.json`, `*_apres.json`, `*_retour.json`, `*_restaure.json`).

## 6. Relectures indépendantes (`relectures/`)
Huit relectures : fb51920 (à corriger), dedb41d (à corriger), 7621ade (valide avec réserves), 432733e (valide avec réserves), e004ee6 (valide avec réserves), e91e7e5 (à corriger : B1 à B3, I1 à I5, M1 à M9), 886075a (à corriger : I5 contournable), **be7cb5d : FAVORABLE, aucun bloquant**. Chaque correction du code a été suivie d'une nouvelle relecture ; la dernière relecture favorable et les dernières suites complètes portent exactement sur le même code (`be7cb5d`).
