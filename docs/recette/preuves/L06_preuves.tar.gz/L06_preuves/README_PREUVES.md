# Lot L06 — archive des preuves et journaux

Données fictives uniquement ; aucun secret (vérifié par recherche du mot de passe de la base temporaire, de clés et de jetons dans tous les fichiers). Les variables d'environnement nécessaires aux commandes (`DJANGO_DEBUG=1`, clé de test, accès à la base de test PostgreSQL) sont fournies à l'exécution et ne sont pas consignées.

## 1. Références Git testées
| Référence | SHA | Rôle |
|---|---|---|
| L29 validé | `c355310` | référence de comparaison |
| Rapport intermédiaire L06 | `2fa183a` | dernier code = `326387b` |
| Rapport final précédent | `1cb08f4` | code testé et relu : `be7cb5d` |
| Code intermédiaire | `e004ee6`, `e91e7e5`, `886075a`, `be7cb5d`, `11e4658` | voir tableau du §4 |
| **Code final testé et relu** | `e94e186` | suites complètes SQLite et PostgreSQL, dixième relecture FAVORABLE |
Les commits suivants de la branche `claude/l06-autorites-technique-metier-v11` ne modifient que la documentation et cette archive (démontré par `git diff --name-only e94e186..HEAD` : uniquement `docs/`).

## 2. Environnement
Python 3.13.18, Django 5.2.17, SQLite 3.53.1, PostgreSQL 16.15 (grappe temporaire locale, UTF8, `fsync=off`), Linux 6.18 ; `manage.py test --parallel 4 --noinput`.

## 3. Commandes exécutées (principales)
- Suites complètes : `python manage.py test --parallel 4 --noinput`, sans base (SQLite) puis avec `DB_HOST/DB_PORT/DB_USER/DB_NAME/DB_PASSWORD` (PostgreSQL), sur chaque référence.
- Migrations : `migration/rejouer.sh sqlite|pg` — création d'une base par le code `c355310`, peuplement de comptes fictifs (`peupler.py`), sauvegarde (copie de fichier ou `pg_dump -Fc`), `migrate` vers le code final, `migrate accounts 0023` (retour arrière), restauration (`pg_restore`), comparaison des profils (`etat.py`, `etat2.py`).
- Essai de retrait du niveau 9 de l'administrateur général (non conservé dans le code) : suite complète SQLite, journal fourni (32 échecs, voir `docs/recette/L06_MIGRATION_ET_PREUVES.md` §13).

## 4. Résultats complets
| Exécution | Moteur | Tests | Résultat | Ignorés | Journal |
|---|---|---|---|---|---|
| Référence `c355310` | SQLite / PostgreSQL 16 | 4021 / 4021 | OK / OK | 20 / 22 | `logs/c355310_reference_*.log` |
| Intermédiaire `326387b` | SQLite / PostgreSQL 16 | 4045 / 4045 | OK / OK | 20 / 22 | `logs/326387b_intermediaire_*.log` |
| Intermédiaire `e004ee6` | SQLite / PostgreSQL 16 | 4083 / 4083 | OK / OK | 20 / 22 | `logs/e004ee6_final_*.log` |
| Intermédiaire `e91e7e5` | SQLite | 4124 | OK | 20 | `logs/e91e7e5_intermediaire_sqlite.log` |
| Intermédiaire `886075a` | SQLite / PostgreSQL 16 | 4135 / 4135 | OK / OK | 20 / 22 | `logs/886075a_intermediaire_*.log` |
| Intermédiaire `be7cb5d` | SQLite / PostgreSQL 16 | 4139 / 4139 | OK / OK | 20 / 22 | `logs/be7cb5d_final_*.log` |
| Intermédiaire `11e4658` | SQLite | 4171 | OK | 22 | `logs/11e4658_intermediaire_sqlite.log` (exécution PostgreSQL interrompue : code corrigé ensuite) |
| **Final `e94e186`** | SQLite / PostgreSQL 16 | **4174 / 4174** | **OK / OK** | 22 / 22 | `logs/e94e186_final_*.log` |
Écart avec la référence : +153 tests ajoutés ; aucun test supprimé. Deux tests de concurrence ne s'exécutent que sur PostgreSQL (d'où 22 ignorés sur SQLite).

## 5. Migrations et restauration (`migration/`)
- `rejouer.sh` (journaux `migration_sqlite.log`, `migration_pg.log`, fichiers `sqlite_*.json`, `pg_*.json`) : chaîne complète 0024 à 0030 appliquée sur une base créée par le code `c355310` et peuplée de comptes fictifs (administrateurs d'unité convertis en équipier + droits techniques, administrateur général converti en indicateur, fonction à confirmer en attente) ; retour arrière à 0023 puis restauration depuis sauvegarde : profils identiques à l'état initial sur les deux moteurs ; les traces de migration sont conservées sous un libellé « _annulee » ou « _non_restauree », jamais supprimées.
- `rejouer_0030.sh` (journaux `migration_0030_sqlite.log`, `migration_0030_pg.log`, fichiers `0030_*.json`, données `peupler_0029.py`, `etat_0030.py`) : base créée par le code de la version initiale de 0029 (`619e686`), peuplée de données fictives (demande bloquée, opérateurs homonymes, compteurs d'identifiants inventés), sauvegardée, mise à niveau vers le code final (0030), retour arrière à 0029, restauration : données identiques à l'état initial sur les deux moteurs ; `makemigrations --check` sans écart.

## 6. Relectures indépendantes (`relectures/`)
Dix relectures : fb51920 (à corriger), dedb41d (à corriger), 7621ade (valide avec réserves), 432733e (valide avec réserves), e004ee6 (valide avec réserves), e91e7e5 (à corriger), 886075a (à corriger), be7cb5d (favorable), 11e4658 (favorable, deux défauts importants corrigés ensuite), **e94e186 : FAVORABLE, aucun bloquant, aucun important**. Chaque correction du code a été suivie d'une nouvelle relecture ; la dernière relecture favorable et les dernières suites complètes portent exactement sur le même code (`e94e186`).
