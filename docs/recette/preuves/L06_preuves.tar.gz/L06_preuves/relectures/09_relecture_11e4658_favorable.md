RELECTURE INDÉPENDANTE L06 — SHA 11e4658 (neuvième relecture ; résumé du rapport remis)

VERDICT : FAVORABLE. Aucun bloquant pour la clôture de L06. Deux défauts importants, dont une régression introduite par ce commit.

Importants
1. L'authentification Basic de l'API créait un « poste connu » (ligne `poste:` et cookie) à chaque requête : après dix appels, le poste du navigateur du titulaire était évincé. Correctif : poste retenu seulement pour une connexion de navigateur.
2. Les clients IPv4 vus en IPv6 « mappé » (::ffff:a.b.c.d) partageaient tous la source « ::/64 ». Correctif : lecture comme IPv4, y compris dans X-Forwarded-For.

Mineurs consignés : socket Unix (source « inconnue » ; mandataire non déclarable), variable MATRIX_MANDATAIRES_DE_CONFIANCE à documenter, postes connus non révoqués au changement de mot de passe par l'utilisateur, plafond de 25 essais par demande bloquant un titulaire sans poste connu (code de 16 caractères : acceptable), coût de calcul à double vérification, contournements hors du modèle des exigences de formation (bulk_create, QuerySet.update, loaddata, fusionner_formations), relèvement automatique plus large que nécessaire, suffixe « (2) » des homonymes pouvant dépasser 128 caractères.

Conformes (sondes réelles) : X-Forwarded-For (client direct, mandataire non déclaré, chaîne forgée, illisible, IPv6, réseau /0 refusé) ; cookie de poste (falsification, autre identifiant, ancienneté, rejeu après réinitialisation, taille) ; verrouillage malveillant depuis une adresse partagée ; indiscernabilité des identifiants (pages, API Basic, une dérivation PBKDF2 dans tous les cas) ; atomicité des compteurs sur SQLite et PostgreSQL 16 ; migration 0029 initiale → 0030 → retour arrière → restauration sur les deux moteurs ; exigences de formation (API JSON et multipart, administration, ORM).
