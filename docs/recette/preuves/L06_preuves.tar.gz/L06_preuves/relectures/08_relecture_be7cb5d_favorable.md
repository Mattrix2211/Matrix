RELECTURE INDÉPENDANTE L06 — SHA be7cb5d (huitième relecture ; résumé du rapport remis)

VERDICT : FAVORABLE. Aucun bloquant.

I5 (AC-20) vérifié par sondes réelles de l'API (commandant puis administrateur général cumulant le commandement) : POST, PUT, PATCH, JSON, multipart, urlencoded ; valeurs booléennes diverses (False, « false », « FALSE », « f », « n », « no », « off », « 0 », 0) ; case absente ; rôle vide, élargi ou égal ; changement de cours, de rôle, de cible (navire, service, secteur, section) : tous refusés (400), la locale reste requise. Passage commune → locale, modification et suppression d'une commune par un commandant : 403. Autres rôles : 403. L'administrateur général crée, modifie et supprime des communes. Le web (training/web_views.py, formulaires, gabarits) ne crée ni ne modifie d'exigence : pas de contournement du sérialiseur. Seules autres écritures : commande `fusionner_formations` et `seed_demo` (get_or_create, required=True).

Re-sondes par échantillon conformes : B1/I3 (annuaire web, édition et lot ; même résultat qu'à l'API), B2, B3 (homonymes et identité système), I1 (12 essais faux depuis une adresse : demande ACTIVE ; le titulaire réussit depuis une autre adresse ; la source fautive reste bloquée), I2 (300 identifiants inventés : 0 ligne), M1 (PostgreSQL 16, 8 threads : aucune 500, une demande ouverte), M3, M4, M5, M8, M2 (test). AC-15 à AC-21 conformes par échantillon.

MINEURS (ne bloquent pas la clôture) : M-a l'exigence commune modifiée est comptée contre elle-même (un PATCH simultané « locale + non requise » de l'unique commune d'un cours est refusé) ; M-b ordre inverse non contrôlé (aucun consommateur des exigences aujourd'hui : à traiter en L38) ; M-c locale ancienne non requise bloquée en modification quand une commune apparaît ; M-d case décochée = faux (sans effet de sécurité) ; M-e interface /admin/ de Django hors périmètre (superutilisateur, intervention technique) ; M-f migrations 0024, 0028, 0029 modifiées sur place (sans effet tant qu'aucun environnement n'a appliqué l'ancienne version ; à vérifier avant déploiement).

Limites : suite complète non relancée par le relecteur ; M2, M4, M5, M8 et la restauration PostgreSQL non rejouées par sonde ; les 154 fichiers du lot non relus un à un ; toutes les écritures POST de chaque module par l'administrateur général non parcourues.

Ce qui bloque la clôture de L06 : rien. Ne bloquent qu'un déploiement futur ou L38 : M-b, M-e, M-f.
