RELECTURE INDÉPENDANTE L06 — SHA e91e7e5 (copie de travail /tmp/relecture_l06e/code, dépôt non modifié, sondes sous /tmp/relecture_l06e/probes)

VERDICT : À CORRIGER. Un défaut exige une correction du CODE avant clôture (B1). B2 et B3 en exigent aussi à mon avis. Les I1 à I3 devraient être corrigés ou explicitement acceptés par le PO.

Les trois bloquants contredisent des garanties que la documentation du lot présente comme prouvées. Je les ai reproduits par sondes réelles.

========== BLOQUANTS ==========

B1. Auto-attribution du rôle COMMANDANT ou SECOND par l'administrateur général via l'annuaire web (AC-15, AC-10, CA-L06-2 « ne s'attribue pas de fonction métier »)
- Où : accounts/web_views.py, action `edit_user` (l. 532 et suivantes) et `bulk_update_role` (l. 304 et suivantes). `_utilisateurs_gerables_par` (l. 77) renvoie tous les comptes pour un administrateur général, soi-même compris. `_role_attribution_autorisee` accepte COMMANDANT, COMMANDANT_EN_SECOND et EQUIPIER pour lui. Aucune interdiction de viser son propre `pk`.
- Sonde : administrateur général (rôle EQUIPIER, sans bâtiment) fait POST /users/ `{action: edit_user, pk: <lui-même>, role: COMMANDANT, ship_id: …}`. Réponse 302, rôle = COMMANDANT. Même résultat avec `bulk_update_role` et COMMANDANT_EN_SECOND.
- L'API refuse le même acte (403 : `ManageUsersPermission.has_object_permission`, auto-modification interdite). Le web est donc incohérent avec l'API.
- Les tests ne couvrent pas ce cas : V08, V17 et V25 visent l'administrateur technique, et `test_l06_statuts` ne teste l'auto-attribution que pour `set_technique`.
- Correctif : refuser dans `edit_user` et `bulk_update_role` toute modification de rôle ou d'autorité sur soi-même, comme le fait l'API. Ajouter des tests web pour l'administrateur général.

B2. Un commandant convertit une exigence de formation COMMUNE en exigence locale (AC-20, CA-L06-23)
- Où : training/views.py, `TrainingRequirementPermission._est_commune` et `has_object_permission` (l. 255 à 285). Le caractère « commun » est déduit du corps de la requête et non de l'objet existant.
- Sonde : un exigence commune existe (aucun `applies_to_*`). Le commandant du bâtiment fait PATCH /api/training/requirements/{id}/ avec `{"applies_to_ship": <son bâtiment>}`. Réponse 200, et l'exigence commune de toute la flotte devient locale à son bâtiment.
- Cause : le patch contient un rattachement, donc `_est_commune` renvoie faux, donc seul le droit de commandement est exigé. L'objet est visible de tous (get_queryset, exigences sans rattachement) et le seuil d'écriture est COMMANDANT.
- Correctif : dans `has_object_permission`, exiger l'administrateur général si l'objet existant est commun (aucun `applies_to_*_id`) ou si la requête le rend commun.
- À ajouter aux tests : PATCH de commun vers local par un commandant, qui doit donner 403.

B3. Double validation des opérateurs de récupération contournable : un seul opérateur ouvre ET valide seul (AC-17)
- Où : accounts/recuperation.py, `valider` (l. 99 et suivantes). Le premier opérateur est retrouvé par `OperateurRecuperation.objects.filter(nom=demande.operateur_initiateur).first()`. `nom` n'est ni unique ni contraint, et `habiliter_operateur` ne vérifie pas son unicité. Seule l'identité système est unique.
- Sonde : deux opérateurs habilités avec le même nom (« Alice », identités système sys-a et sys-b). L'opérateur 2 appelle `ouvrir` puis `valider` seul : `first()` renvoie l'opérateur 1, donc `premier.pk != operateur.pk` et l'identité système diffère. Résultat : la demande est validée, les deux codes sont obtenus par une seule personne.
- Le test « un seul opérateur ne peut pas valider » n'utilise que des noms distincts. Son alias « faux » modifie un objet en mémoire sans le sauvegarder.
- Correctif : stocker le lien vers l'opérateur initiateur par clé étrangère (ou par `identifiant_systeme`), jamais par nom. Rendre `nom` unique. Comparer les identités système et les pk des deux opérateurs réels.

========== IMPORTANTS ==========

I1. Un tiers non authentifié peut empêcher indéfiniment toute réinitialisation ou récupération (déni de service ; AC-18 « protection contre le verrouillage malveillant », AC-21)
- Où : accounts/reinitialisation.py, `utiliser` (l. 147 et suivantes). Le compteur `essais` est propre à la demande et indépendant de la source. Au-delà de TENTATIVES_CODE_MAX la demande passe à BLOQUEE « définitivement ». La page publique /reinitialisation/ n'exige aucune authentification.
- Sonde : demande ACTIVE ouverte pour « adm1 ». Sept POST avec des codes bidon pour cet identifiant depuis une adresse quelconque, et le statut devient BLOQUEE. Le titulaire légitime, avec les bons codes, est refusé. L'attaquant peut recommencer à chaque nouvelle demande, y compris une récupération d'administrateur général qui a mobilisé deux opérateurs.
- Il suffit de connaître un identifiant. Le §18 et le §19 de L06_MIGRATION_ET_PREUVES.md présentent ce risque comme traité, alors qu'il ne l'est que pour la connexion.
- Correctif : compter les essais par couple (demande, source), avec blocage progressif de la source et sans blocage de la demande. Avec 80 bits de code, le blocage de la demande n'est pas nécessaire contre la force brute.
- Test à ajouter : essais d'un tiers puis connexion du vrai titulaire.

I2. Croissance non bornée de CompteurConnexion (AC-18 « accumulation maîtrisée »)
- Où : accounts/securite.py, `enregistrer_echec`. Chaque échec sur un identifiant inventé crée deux lignes (couple et global). Rien n'est plafonné ni mutualisé, et la purge ne retire que ce qui est inactif depuis 30 jours.
- Sonde : 300 tentatives sur 300 identifiants inventés ont créé 600 lignes.
- Un flot à 50 requêtes par seconde donne environ 8 millions de lignes par jour. De plus, la purge opportuniste (1 échec sur 50 environ) fait un DELETE filtré sur `derniere_activite`, qui n'est pas indexé : un balayage complet, qui amplifie le déni de service.
- Correctif : ne pas créer de compteur pour les identifiants inexistants (ou les regrouper dans un compteur borné par source), ajouter un index sur `derniere_activite`, plafonner le nombre de lignes. La ligne « accumulation… Refusé — traité » du §19 doit être corrigée.

I3. Le web est plus permissif que l'API pour l'administrateur général, au-delà de la gouvernance (AC-15)
- Où : accounts/web_views.py, `edit_user` et `bulk_update_role` (l. 304 et 532).
- Sonde : l'administrateur général dégrade un CHEF_SERVICE en EQUIPIER par le web (rôle modifié). La même requête par l'API donne 403, car `has_object_permission` exige que le rôle courant soit dans ROLES_DE_GOUVERNANCE.
- Le web révoque donc toute autorité de bord, alors qu'AC-15 ne confère que la révocation des commandants et seconds.
- Correctif : appliquer côté web les mêmes garde-fous que l'API (rôle courant et rôle visé dans ROLES_DE_GOUVERNANCE).

I4. Preuve de recette héritée de L29 non livrée
- docs/PLAN_LOTS_REPRISE.md l. 92 dit que L06 doit prouver l'exécution des règles `ADMIN-ORGANISATION` et `WEB-QUARTS`. Dans matrix/tests/habilitation/test_matrice_profils.py, `SANS_PREUVE_EXECUTEE` les laisse attribuées à « L06 » (fichier inchangé dans le lot). Le §7 du document de preuves ne les mentionne pas.
- Soit produire ces preuves exécutées, soit les reporter explicitement vers un lot nommé, avec l'accord du PO.

I5. Exigences locales qui « renforcent sans jamais affaiblir » (AC-20) : règle non appliquée par le code
- Sonde : un commandant crée une exigence locale `required=false` pour la même formation et le même rôle qu'une exigence commune ; la réponse est 201.
- Aucun code ne consomme encore les exigences (aucune fusion ni comparaison), donc l'effet est nul aujourd'hui. Mais la règle de non-affaiblissement n'est ni contrôlée ni testée. À borner dans le code ou à reporter explicitement (L38).

========== MINEURS ==========

M1. Concurrence PostgreSQL : deux `initier` simultanés pour la même cible. Sonde sur PG 16 : sur 6 appels simultanés, 5 lèvent IntegrityError non traitée (contrainte `une_demande_ouverte_par_compte`), donc des 500. Même risque dans `recuperation.ouvrir`. Correctif : `select_for_update` sur l'utilisateur ou capture de l'IntegrityError. La contrainte garde l'invariant.

M2. `initier` et `recuperation.ouvrir` annulent toute demande ouverte du compte (`_annuler_ouvertes`), y compris une récupération en cours. Un technique ou un général peut donc annuler une demande de récupération ouverte sur un compte pas encore administrateur général (cas `attribuer`).

M3. `utiliser` (accounts/reinitialisation.py) : `User.objects.filter(username__iexact=…).first()` sans tri. Deux identifiants qui ne diffèrent que par la casse peuvent désigner un autre compte que celui de la demande. Aucune élévation (les codes sont liés à la demande), mais la demande légitime échoue. Préférer une correspondance exacte, puis iexact seulement si le résultat est unique.

M4. `utiliser` pour une récupération avec attribution ne revérifie pas qu'aucun administrateur général n'existe (condition vérifiée seulement à l'ouverture). L'attribution passe par `.update(administrateur_general=True)` sans trace dédiée `changement_administrateur_general` (seul le détail de l'audit `reinitialisation_effectuee` porte `nature=RECUPERATION`).

M5. Migrations, retour arrière. 0024 et 0028 (`restaurer`) font `journal.delete()` : le retour arrière supprime des lignes d'AuditLog. Cela contredit « l'AuditLog n'est jamais purgé » et « jamais d'écrasement silencieux ». Préférer marquer le journal plutôt que le supprimer. Constaté sur PG : 3 lignes de journal disparaissent au retour arrière (le mot de passe provisoire invalidé n'est pas restauré, ce que le §17 documente).

M6. Documentation et libellés obsolètes. docs/recette/L06_MIGRATION_ET_PREUVES.md §19 annonce « 6 à 365 jours » alors que le code borne à 7-365 (settings.py). role_thresholds.py l. 172 : libellé « mot de passe provisoire à changer à la connexion » obsolète (AC-16). Branche `{% if provisoire %}` morte dans registration/password_change_form.html. README.md l. 23 (« createsuperuser ») : une installation neuve suivant le README obtient un superutilisateur sans aucune prérogative applicative. Il faut renvoyer vers la procédure `--attribuer` (§17), sinon le démarrage est bloqué.

M7. Exploitation. `habiliter_operateur_recuperation` sur une identité système déjà habilitée lève un IntegrityError brut (traceback) au lieu d'un CommandError. Les deux opérateurs doivent avoir des comptes système distincts : sur une installation où tous passent par le même compte (root dans un conteneur, compte de service), la procédure à deux opérateurs est inutilisable, ou contournée. À écrire dans les mesures d'exploitation du §12.

M8. Seuils : `update_role_threshold` dispense `is_master_admin` de la borne supérieure (accounts/views.py ou matrix/views.py l. 886 environ). Un cumul administrateur général + COMMANDANT peut poser un seuil métier à MASTER_ADMIN (niveau 9), que plus personne n'atteint pour cet acte (`seuil_role` ne ramène que ADMIN_NAVIRE à COMMANDANT). Sabotage possible par un cumul explicite. Borner à COMMANDANT pour les actes non gouvernance.

M9. La limitation de connexion repose sur REMOTE_ADDR. Derrière un mandataire inverse, tous les marins partagent la même source : 5 échecs d'un tiers bloquent alors l'identifiant pour tous (couple identifiant+source identique). La limite est déjà signalée au §18. Elle devrait aussi apparaître dans les mesures d'exploitation du §12, avec la mention qu'un mandataire de confiance exige un réglage explicite.

========== POINTS VÉRIFIÉS (conformes, par sonde ou lecture) ==========

Séparation des statuts
- Un superutilisateur Django simple (sans indicateur) a exactement les mêmes accès qu'un équipier sur 265 URL sans paramètre (parcours GET), hors /admin/. L'administrateur général sans staff n'accède pas à /admin/. Le niveau métier ne vient que du rôle (`user_role_level`).
- Les usages restants d'`is_superuser` et d'`is_staff` sont anodins : signature de préférences, menu « Ouvrir dans l'administration », exclusions de listes, protection des comptes.
- Aucune dépendance au niveau 9 ou ADMIN_NAVIRE pour un acte métier : `ADMIN_NAVIRE` non technique est ramené à COMMANDANT.

Réinitialisation, vérification indépendante (accounts/reinitialisation.py)
- Cas essayés : initiateur seul refusé ; auto-vérification refusée ; titulaire, équipier et commandant non vérificateurs refusés ; codes inversés refusés ; un second administrateur technique accepté ; réutilisation d'un code refusée ; technique vers commandant refusé ; sessions du titulaire révoquées après usage (302).
- Usage unique concurrent testé sur PG : 3 threads, un seul succès.
- Codes liés à la demande, au compte et au rôle (empreinte salée). Aucun code dans AuditLog ni Notification. Réponses avec Cache-Control no-store. Message d'erreur unique.
- Limite non couverte : la collusion de deux responsables habilités (documentée).

Récupération (hors B3)
- Authentification à deux facteurs de l'opérateur (identité système via `pwd`, phrase hachée). Justification obligatoire, délai, interdit pour un compte non administrateur général sans `attribuer`, procédure `simplifie` refusée hors DEBUG. Pas de compte de secours dans le code.

Connexion (AC-18)
- Compteur atomique par `UPDATE … F()` : 12 threads concurrents sur PostgreSQL (couples et compteur global), aucune erreur, incréments cohérents.
- Source = REMOTE_ADDR, jamais un en-tête client. Échec compté une seule fois par requête. Paramètres bornés (`_entier_borne`) et tâche de purge planifiée.

Migrations
- Migrations 0024 à 0029, SQLite et PostgreSQL 16 (instance temporaire séparée) : ancien ADMIN_NAVIRE vers technique + fonction à confirmer ; MASTER_ADMIN vers indicateur ; provisoire invalidé ; aller, retour arrière jusqu'à 0023, puis nouvel aller, sans erreur. Seule réserve : M5.

Catalogue de formations
- Catalogue et exigences communes réservés à l'administrateur général côté API. Voir B2 pour l'exception.

Autres décisions
- AC-13 (`peut_modifier_seuil`) : cohérent avec la décision pour le technique ; mais voir M8.
- AC-14 (`fonctions.decider`) : verrouillage de ligne `of=("self",)` compatible PG, auto-décision interdite.
- AC-09 (commande d'initialisation) : verrou par `OneToOne`. La contrainte et la gestion des erreurs sont conformes.
- AC-19 (droits techniques) : réservés à l'administrateur général, justification obligatoire, auto-attribution refusée, API et web.
- Relations vers `User` : garde-fou `test_toute_nouvelle_relation…` bien en place.

Non vérifié ou limites de mon contrôle
- Je n'ai pas lancé les suites complètes. J'ai exécuté 49 tests ciblés (test_initialisation_et_recuperation, test_reinitialisation_codes, test_limitation_connexion) : verts.
- Je n'ai pas relu les 154 fichiers modifiés un à un.
- Je n'ai pas parcouru toutes les écritures POST de chaque module pour l'administrateur général : seules les routes du registre, l'annuaire, les Réglages, l'API des profils et les formations ont été sondées.
- Restauration depuis sauvegarde PG non testée (seulement migrations avant et arrière).

Fichiers clés : /tmp/relecture_l06e/code/accounts/web_views.py, /tmp/relecture_l06e/code/accounts/reinitialisation.py, /tmp/relecture_l06e/code/accounts/recuperation.py, /tmp/relecture_l06e/code/accounts/securite.py, /tmp/relecture_l06e/code/training/views.py, /tmp/relecture_l06e/code/matrix/tests/habilitation/test_matrice_profils.py. Sondes reproductibles : /tmp/relecture_l06e/probes/p1.py (B3 et I1), p3.py (B2 et I5), p5.py (I2), p8.py (B1), p9.py (I3), p11.py et p12.py (concurrence PG).