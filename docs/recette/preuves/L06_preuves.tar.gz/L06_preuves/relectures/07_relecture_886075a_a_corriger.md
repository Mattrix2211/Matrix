RELECTURE INDÉPENDANTE L06 — SHA 886075a (septième relecture ; résumé du rapport remis)

VERDICT : À CORRIGER. Un seul défaut bloquant ; les 16 autres points de la sixième relecture sont corrigés (sondes réelles SQLite et PostgreSQL 16).

BLOQUANT
B-NEW-1 — I5 contournable (training/views.py, `_affaiblit_exigence_commune`) : une exigence locale pouvait rendre facultative l'exigence commune
 - valeurs booléennes « FALSE », « f », « F », « n », « no », « NO », « Off », « OFF » acceptées (200) ;
 - PUT multipart sans la case « required » (valeur existante lue au lieu de la valeur finale) ;
 - locale sans rôle face à une commune « EQUIPIER » non détectée.
 Correctif demandé : contrôle dans `TrainingRequirementSerializer.validate()` sur les valeurs validées ; tests « no », « FALSE », multipart, rôle élargi.

MINEURS (ne bloquent pas la clôture)
m1 reprises SQLite absentes sur `initier`/`ouvrir` (SQLite réservé au développement ; PostgreSQL : 24 essais sur 24 sans erreur) ; m2 compteurs bornés par (identifiant existant × adresse) ; m3 clé « code:<id> » partagée avec les identifiants ; m4 journal de migration renommé même sans restauration effective ; m5 migration 0029 modifiée après coup (à vérifier avant tout déploiement) ; m6 mandataire inverse (documenté) ; m7 seuils de gouvernance montables à MASTER_ADMIN par l'administrateur général ; m8 docstring de reinitialisation.py.

CONFORMES (sondes) : B1, B2, B3, M7, M9, I1, I2, I3, M1 (PostgreSQL : 6 rafales de 4 appels, une seule demande ouverte, aucune erreur 500), M2, M3, M4, M5, M6, M8. I4 lu dans le diff seulement.

Suite donnée : correctif I5 (serializer), journal de migration nommé « _annulee » ou « _non_restauree » selon la restauration effective, docstring corrigée ; nouvelle suite complète et nouvelle relecture sur le code final.
