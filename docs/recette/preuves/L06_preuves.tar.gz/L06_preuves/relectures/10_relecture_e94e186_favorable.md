RELECTURE INDÉPENDANTE L06 — SHA e94e186, code final (dixième relecture ; résumé du rapport remis)

VERDICT : FAVORABLE. Aucun bloquant, aucun important. La clôture de L06 peut se faire.

Défaut 1 (poste connu créé par l'API Basic) : corrigé sans régression, sur SQLite et PostgreSQL 16. Aucune ligne `poste:` ni Set-Cookie pour l'API Basic ; statuts et corps identiques à ceux du 11e4658 (200 ; 403 au message unique pour mauvais mot de passe, identifiant inexistant et adresse bloquée) ; authentification DRF par session sans poste ; connexion de navigateur : poste retenu, exemption du blocage de l'adresse partagée, renouvellement sans doublon.
Défaut 2 (IPv4 mappé) : corrigé. ::ffff:a.b.c.d et formes équivalentes donnent la source IPv4 ; IPv6 non mappées en /64 ; formes dégénérées ou mal formées sans erreur 500 ; X-Forwarded-For lu en IPv4 derrière un mandataire déclaré.
Re-sondages : migration 0029 initiale → 0030 → retour arrière → restauration sur les deux moteurs (suffixe d'homonymes tronqué vérifié avec des noms de 128 caractères) ; 90 tests ciblés ; indiscernabilité des identifiants ; cinq essais de code par source ; plafond de 25 essais par demande.

Mineurs (ne bloquent qu'un déploiement futur, consignés au §18) : 1) un mandataire déclaré en forme IPv6 mappée n'est jamais rapproché du client direct (panne sûre) : déclarer en IPv4 pur ; 2) la réussite d'un titulaire par son poste connu remet à zéro le compteur de l'adresse partagée (non exploitable sans le mot de passe) ; 3) si un frontal impose une authentification Basic à tout le site, les navigateurs ne retiennent plus de poste (panne sûre).

Limites du contrôle : suite complète non relancée par le relecteur ; pas de sonde ORM contournant save() (update, bulk_create) ; pas de mandataire ni de charge réels.
