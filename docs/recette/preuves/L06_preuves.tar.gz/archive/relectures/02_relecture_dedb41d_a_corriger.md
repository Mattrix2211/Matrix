# Relecture 2 — état dedb41d — verdict À CORRIGER

(Rapport du relecteur indépendant, repris tel que remis.)

RAPPORT DE SECONDE RELECTURE L06 (lecture seule, HEAD dedb41d contre c355310)

Méthode : lecture du diff, puis sondes exécutées dans /tmp/relecture_l06b/probe_l06.py (hors dépôt, base SQLite temporaire). La seule exécution de tests existants que j'ai tentée (accounts + matrix.tests.habilitation, parallélisme 2) a été tuée (code 137, redémarrage du conteneur) : je n'ai aucun résultat de suite à rapporter. Chaque constat ci-dessous vient de la lecture du code ou d'une sonde.

VERDICT : À CORRIGER

Les neuf points de la première relecture sont corrigés dans l'ensemble. Deux d'entre eux le sont de façon incomplète (points 5 et 6, voir B1 et I1), et le point 7 reste partiel (I2). Aucune élévation de privilège directe par l'API des profils n'a été trouvée.

---

## BLOQUANT

**B1. Un administrateur technique sans autorité métier peut abaisser les seuils de circuits de validation et se donner ainsi des droits métier (point 5 non clos).**
- Fichier : matrix/views.py:863-870 (`update_role_threshold`) et matrix/core/role_thresholds.py (le plancher n'existe que sur 4 actions : structure_navire_ecriture, unite_administration, module_gestion, programme_types).
- Sonde : `admin_navire` (rôle ÉQUIPIER + drapeau technique) a posté `update_role_threshold` vers EQUIPIER sur `liste_service_publication`, `feuille_service_visa_service`, `alerte_organisation_validation` et `feuille_service_configuration`. Les quatre ont répondu 302 et `seuil_role` renvoie EQUIPIER pour chacune.
- Conséquence : il peut ensuite publier, viser et valider en tant qu'équipier. Cela contredit AC-02 (« modification des circuits de validation : commandant ou délégataire ») et CA-L06-2.
- `reset_role_threshold` (matrix/views.py:~885) produit le même effet : il fait revenir à un défaut plus bas un seuil que le commandement avait renforcé.
- Le test V24 (`asset_ecriture_simple` -> EQUIPIER accepté pour `admin_navire`) fige ce comportement pour un seuil sans plancher. Il ne couvre aucun seuil de circuit.
- Correctif : poser un plancher sur les seuils de circuits (publication, visas, configuration de feuille de service, validation d'alerte, etc.). À défaut, interdire à l'administrateur technique sans autorité métier de modifier ou réinitialiser tout seuil non technique (seul `mot_de_passe_reinitialisation` lui resterait ouvert). Ajouter des tests sur ces seuils, y compris la réinitialisation.

---

## IMPORTANT

**I1. La liste `DESIGNATIONS` des comptes non réinitialisables est incomplète (point 6 partiel).**
- Fichier : accounts/services.py:~50-60.
- Sonde : `peut_reinitialiser_cible(admin_navire, cible)` renvoie True pour un compte portant `training.PersonnelBRH` (relation `navires_brh`, valide les candidatures de formation) et pour un compte portant `training.ReferentFormationNavire` (relation `navires_dont_il_est_referent_formation`, « autorité de validation sur TOUTES les formations du navire »).
- Même défaut par lecture du code, non sondé : `quarts.RemplacementChefDeListe` (relation `remplacements_chef_de_liste`, droit d'activer ou de retirer une prévision) et `assets.ChefResponsableSpecialite` (relation `responsables_specialite_diriges`, vise les propositions d'article).
- Scénario : l'administrateur technique réinitialise le mot de passe de ce compte, se connecte avec le mot de passe provisoire et reprend l'autorité du titulaire.
- Aucun test ne couvre `porte_une_designation`.
- Correctif : compléter la liste, ou mieux, la dériver d'un registre des désignations unique (réutiliser le socle L29) pour qu'un nouveau modèle de désignation ne puisse plus être oublié. Ajouter un test paramétré par désignation.
- Mineur associé : dans `set_password` (accounts/web_views.py:~680), `reinitialiser_mot_de_passe` lève PermissionDenied, donc une page 403 brute, alors que la version en masse filtre proprement.

**I2. La migration 0024 promeut toujours à ÉTAT_MAJOR sur la seule présence d'un `fonction_coma` (point 7 partiel).**
- Fichier : accounts/migrations/0024_administrateur_technique.py:17-22.
- Seul le doublon de titulaire a été corrigé. Or `est_titulaire` (matrix/core/commandants_adjoints.py:60-65) exige `role == ETAT_MAJOR`.
- Avant migration, un ADMIN_NAVIRE ne tenait donc aucune fonction, même avec `fonction_coma` renseigné. Ce champ est inerte hors ÉTAT_MAJOR, donc potentiellement périmé.
- La promotion crée une autorité nouvelle (visas par service, écriture bornée aux services rattachés). C'est une déduction à partir d'une valeur inerte, ce qu'AC-01 interdit (« fonction explicitement établie », « aucune fonction déduite »).
- Autre défaut : le choix du « premier » compte de même fonction dans un bâtiment dépend de l'ordre non défini du queryset (arbitraire sous PostgreSQL).
- Correctif : convertir systématiquement en ÉQUIPIER + `administrateur_technique`, journaliser la fonction présente pour confirmation par une autorité habilitée, et adapter test_l06_migration et la matrice du document de preuves §3.

**I3. Seuils déjà enregistrés à « ADMIN_NAVIRE » : plus aucune autorité ne peut les franchir.**
- Fichier : matrix/core/role_thresholds.py:271-276 (`RoleLevel[nom]`, puis `_avec_plancher`).
- Sonde : `RoleThresholdConfig(thresholds={"structure_navire_ecriture": "ADMIN_NAVIRE", "module_gestion": "ADMIN_NAVIRE"})` donne un seuil effectif ADMIN_NAVIRE (8). Seul MASTER_ADMIN atteint ce niveau, donc le commandant perd structure et modules.
- La migration 0024 ne normalise pas ces surcharges.
- Correctif : migration de données qui remplace ADMIN_NAVIRE par COMMANDANT dans `RoleThresholdConfig.thresholds` pour les actions non techniques, avec audit. Alternative : écrêter dans `seuil_role` pour toute action non technique.

**I4. Test creux : `test_le_drapeau_technique_ne_se_modifie_pas_par_l_api_des_profils`.**
- Fichier : matrix/tests/habilitation/test_l06_autorites.py, dans `ApiProfilsTests`.
- Il accepte 200 ou 403, puis ses assertions s'écrivent « drapeau vrai OU statut 403 » : il passe dans les deux cas et ne vérifie rien.
- V19 prouve que l'accès est accordé, mais aucun test ne vérifie l'audit `changement_droits_techniques` avec ses valeurs avant/après, ni l'absence de modification (aucune ligne d'audit) quand la valeur est inchangée.
- Autres tests manquants :
  - `administrateur_technique` envoyé en multipart ou avec des valeurs de formulaire (« on », « false ») ;
  - un technique qui retire le drapeau à un autre (voir M2) ;
  - l'accès de l'administrateur technique à un profil sans `ship` renseigné (voir M1).
- Le test multipart (`PUT {"grade": ""}`) vise `equipier_b1`. Il ne prouve donc pas, pour `equipier_b1`, que le drapeau d'un compte technique n'est pas retiré.
- Correctif : remplacer par des assertions précises, avec codes et valeurs exacts.

---

## MINEUR

**M1. L'administrateur technique est refusé sur les profils sans `ship` direct, alors qu'ils figurent dans son périmètre.**
- Fichier : matrix/core/permissions.py:~172 (`obj.ship_id == profile.ship_id`).
- `perimetre_navire_q` couvre aussi les profils rattachés seulement par service, secteur ou section (docstring de scopes.py:100-115).
- Scénario : un technique modifie le grade d'un marin dont seule la section est renseignée, et reçoit un 403.
- Correctif : comparer `navire_id_effectif` (ou `ship_id_for_user`) des deux côtés, ou s'appuyer sur le queryset déjà borné.

**M2. Un administrateur technique peut retirer le drapeau à n'importe quel autre administrateur technique de son bâtiment, y compris le dernier.**
- Sonde : la requête de `admin_navire` retirant le drapeau de `cdt_admin` renvoie 200, et celle sur `bsc_admin` aussi.
- Risque : verrouillage de l'administration technique du bâtiment (seul MASTER_ADMIN peut le rétablir).
- Correctif : refuser de retirer le dernier administrateur technique actif d'un bâtiment, ou réserver le retrait à l'autorité qui l'a posé.

**M3. Incohérence entre l'API et le web sur les comptes techniques.**
- Le web masque les comptes `administrateur_technique` aux non-techniques (accounts/web_views.py:~94-96).
- Sonde : l'API laisse le commandant modifier le rôle d'un compte technique (200).
- Les deux points d'entrée devraient suivre la même règle.

**M4. Le drapeau technique est attribuable sans trace dans l'administration Django.**
- Fichier : accounts/admin.py.
- Il n'y a aucun audit à la sauvegarde, alors que CA-L06-6 annonce « tout changement d'habilitation est tracé ». Le rôle y est correctement filtré (ADMIN_NAVIRE exclu).
- Correctif : `save_model` qui journalise les changements de `role` et d'`administrateur_technique`.

**M5. La navigation n'a pas été adaptée au nouveau droit technique.**
- Fichier : matrix/core/navigation.py:~44 et 101 (`_commandant_ou_plus`).
- L'entrée « Annuaire » reste masquée à l'administrateur technique, alors que `UserDirectoryView` lui ouvre la lecture et la réinitialisation. L'entrée « Paramètres » le renvoie vers `?tab=notifications`, et l'onglet Sécurité n'est joignable qu'en tapant l'URL.
- Le document de preuves §5 annonce « annuaire : lecture et réinitialisation » sans voie d'accès depuis le menu.

**M6. Résidus dans les documents et les commentaires.**
- docs/recette/L06_MIGRATION_ET_PREUVES.md §9 et §10 contiennent encore les marqueurs `__RESULTATS__` et `__RELECTURES__`.
- Commentaires périmés, non traités : matrix/views.py:276, 287, 306, 367, 841 ; accounts/web_views.py:45, 76, 171, 271, 290, 419 ; accounts/serializers.py:34-41 ; matrix/core/permissions.py:20 ; matrix/core/mixins.py:71 ; org/views.py:21 ; matrix/core/scopes.py:28, 104, 161 ; matrix/styleguide.py:3.
- Ils mentionnent encore « ADMIN_NAVIRE ». Le document de preuves assume le non-réécrit, mais ils décrivent un rôle qui n'existe plus.

**M7. Un administrateur technique peut relever un seuil technique jusqu'à MASTER_ADMIN.**
- Fichier : matrix/views.py:866 (l'exception `not action_seuil.technique`).
- Il peut ainsi verrouiller `mot_de_passe_reinitialisation` pour tous les techniques du bâtiment. Plafonner à ADMIN_NAVIRE pour une action technique.

---

## POINTS VÉRIFIÉS CORRECTS

1. **Point 1 (fonction_coma par PATCH).**
   - Un administrateur technique envoyant `fonction_coma` reçoit un 403 : `has_permission` refuse tout champ d'autorité sans rôle (CHAMPS_AUTORITE).
   - Même avec rôle présent, `has_object_permission` exige un niveau commandant pour changer `fonction_coma`.
2. **Point 2 (auto-élargissement).**
   - Service, secteur, section, `allowed_sectors`, `equipage` et `ship` sont refusés à l'administrateur technique.
   - Aucun rôle ne peut être modifié sur son propre profil (contrôle `user_id == request.user.pk`).
   - Le cas multipart de `allowed_sectors` (`.get` ne renvoie que la dernière valeur) n'ouvre pas de brèche : la présence de la clé suffit pour refuser en `has_permission`, et un compte ne peut pas se cibler lui-même par un rôle de sa propre matrice.
3. **Point 3 (PUT multipart).** `administrateur_technique` est en `read_only_fields` : un formulaire sans la clé ne le retire jamais, et seule la vue le pose, après contrôle de l'autorité.
4. **Point 4 (audit des droits techniques).**
   - `changement_droits_techniques` est écrit avec les valeurs avant/après.
   - `changement_role` et `changement_fonction` sont également tracés.
   - L'autorité est contrôlée en amont : un non-technique envoyant la clé reçoit un 403 (V19, V20 : refus pour commandant, second, chef et équipier ; auto-attribution refusée).
   - Réserve : voir I4 pour la qualité des tests.
5. **Point 5 (partie corrigée).**
   - Le relèvement d'un seuil non technique au-dessus du commandant est refusé aux non-MASTER.
   - Les planchers de `module_gestion` et des trois autres actions résistent même à une valeur EQUIPIER stockée en base (`_avec_plancher`).
   - Le refus est testé (V21, `test_les_autorites_minimales_ne_peuvent_pas_etre_abaissees`).
   - Reste B1 pour les seuils sans plancher.
6. **Point 6 (partie corrigée).**
   - `peut_reinitialiser_cible` refuse l'auto-réinitialisation, les comptes au-dessus de chef de section, les superutilisateurs, les administrateurs techniques, les titulaires de `fonction_coma` et les désignations répertoriées (chef de liste, rédacteur de feuille, délégation de programme, référent de formation, responsable de spécialité, de classe).
   - La réinitialisation de masse filtre les comptes non réinitialisables.
   - Le commandant cumulant le droit technique garde le périmètre étendu.
   - Reste I1 pour les désignations non répertoriées.
7. **Point 7 (partie corrigée).**
   - Le doublon de titulaire est évité.
   - Le retour arrière ne restaure que les comptes dont rôle et drapeau correspondent encore à l'état migré, et il ne touche pas un rôle modifié depuis.
   - La migration est réversible : l'ordre `AddField`, `AlterField` (choix seulement, sans SQL) puis `RunPython` ne pose pas de difficulté en transaction sous PostgreSQL.
   - Les modèles historiques ne déclenchent pas le refus d'ADMIN_NAVIRE de `save()`.
   - Les longueurs d'`AuditLog.action` (128) et de `details` sont respectées.
   - Reste I2 pour la promotion à ÉTAT_MAJOR.
8. **Point 8 (Django admin).** `UserProfileAdmin.formfield_for_choice_field` retire ADMIN_NAVIRE des choix.
9. **Point 9 (commentaires).** Les lignes modifiées sont à jour. Les commentaires périmés restants sont listés en M6.
10. **Autres contrôles sans anomalie.**
    - `save()` refuse ADMIN_NAVIRE ; le sérialiseur le refuse en 400 (`validate_role`) ; le web l'exclut (`_role_attribution_autorisee` et `_referentiels_formulaire`). Aucun point de création de profil ne l'utilise hors tests et migrations.
    - Le seed de démonstration crée l'administrateur d'unité comme ÉQUIPIER + technique.
    - La MANAGE_MAP de l'API et celle du web sont partagées, sans système d'autorisation parallèle. Le commandant en second et l'état-major ne désignent plus de chefs de service.
    - Le cloisonnement inter-bâtiments tient : V07 et V16 refusent `admin_abe` et `cdt_abe`, et le périmètre est borné par `perimetre_navire_q` dans l'API et dans l'annuaire web.
    - Les droits légitimes du commandant (désignations, structure, modules, fuseau, relève, COMANAV) sont conservés par les planchers à COMMANDANT. Le commandant ne peut plus réinitialiser un mot de passe (seuil technique) ; c'est cohérent avec le défaut précédent (8) et documenté.
    - La création de formation est réservée aux techniques, de façon cohérente dans l'API (`CatalogueFormationPermission` + `_exiger_catalogue`) et dans le web.
    - La dérivation du droit technique (`niveau_pour_action` avec `technique=True`) réutilise le registre de seuils existant.

Fichiers de référence : /home/user/wt_l06/matrix/core/permissions.py, /home/user/wt_l06/matrix/core/role_thresholds.py, /home/user/wt_l06/matrix/views.py, /home/user/wt_l06/accounts/services.py, /home/user/wt_l06/accounts/migrations/0024_administrateur_technique.py, /home/user/wt_l06/accounts/web_views.py, /home/user/wt_l06/accounts/views.py, /home/user/wt_l06/matrix/tests/habilitation/test_l06_autorites.py. Sonde exécutée : /tmp/relecture_l06b/probe_l06.py.
