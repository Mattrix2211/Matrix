# Relecture 5 — ÉTAT FINAL e004ee6 — verdict VALIDE AVEC RÉSERVES

(Rapport du relecteur indépendant, repris tel que remis.)

RAPPORT DE RELECTURE FINALE L06 (état e004ee6, diff 432733e..e004ee6)

Relecture en lecture seule. Base SQLite temporaire sous /tmp/relecture_l06d, aucune suite complète, pas de PostgreSQL (lecture du code seulement). Le dépôt n'a pas été touché : `git status` est propre, HEAD = e004ee6.
Tests rejoués : `matrix.tests.habilitation` et `accounts` en entier, --parallel 2, 278 tests, OK (1 ignoré). `makemigrations --check` : aucun changement.

VERDICT : VALIDE AVEC RÉSERVES
- Les quatre points I-1 à I-4 et tous les mineurs demandés sont corrigés et vérifiés par sonde.
- Aucun bloquant, aucune élévation de privilège.
- Aucun défaut n'exige absolument une correction avant clôture.
- Un correctif de deux lignes est recommandé (M-1, concurrence du compteur).

BLOQUANTS : aucun.

IMPORTANTS : aucun nouveau.

MINEURS (nouveaux, introduits par les corrections)

M-1. Compteur d'échecs : lecture, incrément puis écriture non atomique.
- Fichier : accounts/authentification.py, `enregistrer_echec`.
- `select_for_update` ne fait rien sur SQLite. Sondé avec 6 threads qui font 10 échecs chacun sur un fichier SQLite : 52 échecs comptés sur 60 attendus, et un `OperationalError: database is locked` levé depuis `authenticate`.
  - Les incréments perdus affaiblissent un peu le verrouillage face à une attaque parallèle.
  - L'erreur remonte en 500 sur la page de connexion.
- Sur PostgreSQL, `select_for_update` plus `get_or_create` posent un verrou de ligne : pas de perte attendue (lecture du code, non exécuté).
- Correctif : `EchecConnexion.objects.filter(pk=...).update(essais=F("essais") + 1)`, avec capture de `OperationalError` pour traiter l'échec comme un refus.
- Ce n'est pas bloquant : un SQLite de production sous forte concurrence est déjà hors cible.

M-2. La table `EchecConnexion` grossit sans limite.
- Une ligne est créée pour chaque identifiant inconnu : 50 identifiants inventés ont donné 50 lignes. Elle n'est vidée que par un succès du même identifiant.
- Chaque échec devient aussi une écriture en base, qui peut verrouiller SQLite (M-1).
- Correctif : purger les lignes dont `debut` dépasse la fenêtre, par exemple au passage dans `enregistrer_echec`, ou par une tâche périodique ; ou ne compter que les identifiants existants. Le choix est à arbitrer, car compter aussi les inconnus évite d'énumérer les comptes.

M-3. Une requête Basic API fausse compte deux échecs.
- Le middleware et DRF appellent chacun `authenticate`. Sondé : 1 requête donne `('cdt_b', 2)`.
- Le verrouillage vient donc après 3 requêtes au lieu de 5 en API. Plus strict, sans danger. À documenter.

Risque accepté, déjà écrit dans le docstring : n'importe qui peut verrouiller 15 minutes un identifiant connu, y compris le commandant. Sondé : 5 mauvais essais verrouillent aussi le bon mot de passe.
- La fenêtre se mesure depuis le premier échec (`debut`), pas depuis le dernier : un verrou ne se prolonge pas tout seul.
- La commande de récupération efface désormais le verrou en base, donc le serveur le voit.

POINTS VÉRIFIÉS

- I-1 corrigé : `mot_de_passe_provisoire_expire_le` est en lecture seule dans le sérialiseur. Un PATCH `{"mot_de_passe_provisoire_expire_le": "2099-..."}` renvoie 200 mais l'année reste 2026. Le test ajouté couvre les rôles administrateur technique, commandant et chef de service.
- I-2 corrigé :
  - Compteur en base (`EchecConnexion`), identifiant unique. Il est partagé entre processus, puisque c'est la base.
  - Verrou à 5 essais, y compris avec le bon mot de passe. Fenêtre de 15 minutes. Le succès efface la ligne.
  - Un identifiant de 400 caractères ne plante pas (clé tronquée à 150).
  - La commande de récupération appelle `effacer_echecs`. Le docstring est maintenant exact.
  - Tests mis à jour, y compris l'expiration de la fenêtre.
- I-3 corrigé, web et API :
  - Un technique ne retire plus le drapeau d'un technique. Sondé : PATCH JSON avec `false`, `"0"` ou `"off"`, PUT et PATCH form-encoded : 403 dans tous les cas, le drapeau reste vrai.
  - Web `set_technique` avec une valeur autre que "1" : 403.
  - L'administrateur général retire bien (200).
  - Attribuer le drapeau à un non-technique reste permis au technique, comme voulu.
  - Chaîne retrait puis réinitialisation fermée : le test ajouté vérifie que `set_password` sur le pair est refusé (302, mot de passe inchangé).
- I-4 : les documents sont commités et l'arbre est propre.
- Mineurs :
  - Décision inconnue : `ValidationError("Décision inconnue.")`, testé.
  - Acteur sans bâtiment : 403, testé.
  - Cumul implicite à l'initialisation : refusé si le commandant est déjà technique et qu'un autre technique est désigné, testé.
  - Expiration des provisoires existants dans 0025 : sondé sur une base à 0024 avec un provisoire sans échéance. Après migration, l'échéance est posée à maintenant + 48 h.
  - `set_technique` sans profil : le profil est créé (302), plus de 500.
  - Tests creux remplacés : le test multipart cible maintenant un compte technique avec un PUT sans clé booléenne et vérifie que le drapeau reste vrai. Le test d'unicité désactive le commandant et vérifie le verrou en base. `APRES` vaut 0027.
  - `porte_une_designation` supprimée.
- Migrations sur SQLite, avec un jeu de données :
  - Aller 0024 → 0027, retour 0023, ré-application : tout passe sans erreur.
  - 0025 : l'échéance est posée en avant, `noop` en arrière.
  - 0027 : création et suppression de la table `EchecConnexion`.
  - PostgreSQL non exécuté : `CreateModel` simple, contrainte unique ordinaire, rien de spécifique au moteur.
- Concurrence de l'initialisation et de la décision de fonctions (`select_for_update(of=("self",))`, unicité en base) : inchangée depuis la première relecture, lecture du code valide pour PostgreSQL ; sur SQLite, les transactions sont sérialisées par le moteur.

Question au PO, hors code : l'attribution de droits techniques à un compte qui ne l'est pas reste ouverte à tout technique (§13 du document de preuves).
