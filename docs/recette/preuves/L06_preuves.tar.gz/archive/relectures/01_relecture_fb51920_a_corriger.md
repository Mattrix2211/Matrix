# Relecture 1 — état fb51920 — verdict À CORRIGER

(Rapport du relecteur indépendant, repris tel que remis.)

RELECTURE L06 (fb51920 sur c355310, lecture seule, aucun fichier du dépôt modifié)

Les tests exécutés ont tous réussi : `matrix.tests.habilitation`, 60 tests OK. J'ai aussi écrit un banc d'essai hors dépôt (`/tmp/claude-0/probe/l06probe.py`) pour confirmer par l'API les failles ci-dessous.

VERDICT : À CORRIGER. Le socle est bon, mais il y a un bloquant : un administrateur technique peut encore se donner ou donner une autorité métier par l'API.

Le socle bon : séparation du drapeau, planchers lus après la configuration (`seuil_role`) et refusés dans `/parametre/`, garde `ProfileSave`, migration 0024 sans déduction. L'auto-attribution du rôle ou du drapeau est bien refusée. Le commandant ne peut pas se promouvoir. L'état-major ne désigne plus les chefs de service. Le payload sans `role` est correct : il faut le droit technique, et `role=""` donne un 400 DRF.

## BLOQUANT

1. **Désignation et auto-attribution d'une fonction de commandant adjoint par un administrateur technique.**
   - Où : `matrix/core/permissions.py:121-153` et `accounts/serializers.py:15-18`. Le serializer expose `fields="__all__"`, donc `fonction_coma`, `service`, `sector`, `section`, `allowed_sectors`, `equipage`.
   - Scénario testé : un technique sans `role` dans le payload fait `PATCH /api/accounts/profiles/<id>/ {"fonction_coma":"COMAEQ"}` sur n'importe quel état-major du bâtiment. Réponse 200, la fonction est posée.
   - Cas aggravant : un compte état-major + technique fait la même chose sur son propre profil (200). Il s'attribue COMAEQ, donc le droit de modifier les délais (`quarts/configuration_views.py:33`), la validation des échanges, etc.
   - Contraire à AC-02 : « désignation des commandants adjoints = Commandant » et à ARB-01 : « pas d'auto-attribution ».
   - Aucune vérification V ne couvre ce cas : V18, V19 et V20 ne testent que `role` et `administrateur_technique`.
   - Correction suggérée : en l'absence de droit métier suffisant, refuser dans la permission ou le serializer toute modification de `fonction_coma`. Réserver ce champ au commandant et à l'administrateur général, via la matrice ou un contrôle serveur.
   - Par prudence, refuser aussi à tout compte de modifier ses propres `fonction_coma`, rattachements et `allowed_sectors`. Ajouter les tests V correspondants.

## IMPORTANT

2. **Auto-élargissement du périmètre de données par l'API.**
   - Un technique avec service et secteur fait `PATCH` sur son propre profil `{"service":S2,"sector":Sec2}` puis `{"allowed_sectors":[Sec2]}`. Les deux réponses sont 200 et le périmètre de lecture change (testé).
   - Cause : `technique_sur_son_batiment` autorise tout champ hors rôle et drapeau. Correction : liste blanche de champs modifiables par un technique (grade, mot de passe provisoire, etc.), jamais le rattachement ni la fonction d'un compte autorité ou du sien.

3. **Un commandant retire le drapeau technique par un PUT multipart ou formulaire.**
   - `_modifie_droits_techniques` (`permissions.py:107-108`) teste la présence de la clé. Un `PUT` multipart avec `role` mais sans `administrateur_technique` donne 200. DRF lit alors le BooleanField absent comme `False` (HTML) et le drapeau tombe (testé : `tech flag: False`). Le même `PUT` en JSON laisse le drapeau intact.
   - Un commandant non technique modifie donc des droits techniques, ce qu'interdit AC-02.
   - Correction : dans `has_object_permission`, comparer la valeur résultante, ou ajouter `read_only` / retirer le champ côté serializer quand l'acteur n'est pas technique. Ajouter un test en multipart.

4. **L'attribution ou le retrait des droits techniques n'est pas tracé.**
   - `accounts/views.py:53` (`perform_update`) n'écrit l'audit que si le rôle change. Testé : un technique donne le drapeau à un équipier, 200, `AuditLog` vide.
   - Contraire à CA-L06-6 et au principe 8. La doc (`L06_MIGRATION_ET_PREUVES.md` §6) affirme à tort que tout est tracé.
   - Correction : AuditLog `changement_droits_techniques` avec acteur, cible, ancien et nouveau état. Couvrir aussi la fonction.

5. **Un technique peut se donner de l'autorité métier par la configuration des seuils.**
   - L'onglet « Sécurité » (`matrix/views.py:840-880`) lui permet d'abaisser n'importe quel seuil sans plancher à `EQUIPIER`. Exemples : `alerte_organisation_validation` (« valider une modification de l'organisation sécurité », défaut Commandant), `feuille_service_visa_service`, `liste_service_publication`, `poste_gestion`, `documentation_validation`.
   - Il exerce ensuite l'acte lui-même, car son niveau d'équipier suffit. C'est une auto-élévation indirecte.
   - Seuls 4 planchers existent (décidés par le PO). Faire arbitrer par le PO : planchers supplémentaires, ou interdiction à un technique sans fonction d'abaisser un seuil supérieur à chef de section.
   - À l'inverse, `RoleLevel` propose aussi `ADMIN_NAVIRE` et `MASTER_ADMIN` comme valeurs de seuil. Un technique peut donc rendre `module_gestion` ou `structure_navire_ecriture` inaccessibles au commandant (déni d'autorité). Correction : borner le choix à l'échelle métier jusqu'à COMMANDANT, hors seuils techniques.

6. **Reprise de compte d'une autorité hors rôle.**
   - `accounts/services.py:_reinitialisable_par_technique` ne regarde que le rôle. Un technique réinitialise le mot de passe d'un équipier ou chef de section qui porte une autorité hors rôle : chef de liste, BSC, délégation de programme, responsable de spécialité ou de classe, référent de formation.
   - Correction : exclure les comptes portant une désignation (`ChefDeListe`, `DelegationProgramme`, `ResponsableSpecialite`, etc.), ou le renvoyer au PO via la question 5 de la proposition. À arbitrer.

7. **Migration 0024 : promotion en état-major par la seule présence d'un `fonction_coma`.**
   - `fonction_coma` n'avait aucun effet pour un ADMIN_NAVIRE (`commandants_adjoints.py` exige `role==ETAT_MAJOR`). Une valeur ancienne ou périmée devient une fonction active de commandant adjoint (COMAEQ, COMANAV…), possiblement en doublon avec le titulaire réel.
   - Correction : ne promouvoir que si aucun autre titulaire actif n'existe pour cette fonction. Sinon équipier + journal « à confirmer ». À défaut, faire confirmer explicitement par le PO que « renseigné = établi ».
   - Un point de réversibilité (`accounts/migrations/0024_administrateur_technique.py:26-33`) : `restaurer` remet `ADMIN_NAVIRE` à tout compte journalisé encore technique, même si son rôle a changé depuis (ex. devenu commandant). Correction : ne restaurer que si `role` vaut encore la valeur « apres » du journal. Le retour arrière n'est sinon sûr qu'avec la sauvegarde, comme la doc le dit.

8. **Incohérence UI / API de périmètre pour le technique.**
   - `accounts/views.py:49` donne au technique les profils de tout le bâtiment, mais `matrix/core/mixins.py:68` (`utilisateurs_visibles_par`, `UserViewSet`) le limite à sa branche. Son annuaire et ses listes divergent. À aligner.
   - Le web exclut les comptes techniques pour un non-technique (`_utilisateurs_gerables_par`), l'API non. Un commandant peut modifier le rôle d'un compte technique par l'API. Acceptable, mais à documenter.

## MINEUR

9. `matrix/core/role_thresholds.py:292` : pour une action `technique`, un administrateur général reçoit toujours 8. Si le seuil est mis à `MASTER_ADMIN` (9), même le MASTER n'y accède plus (il était au niveau 9 avant). Correction : `max(niveau_ecriture, ADMIN_NAVIRE)` pour un technique.
10. `accounts/web_views.py` (`bulk_reset_passwords`, ligne ~387) : `reinitialiser_mot_de_passe` lève `PermissionDenied` en cours de boucle. Cela arrive avec un technique + chef de service et une cible chef de secteur. Les mots de passe des cibles précédentes sont déjà réinitialisés (aucune transaction visible) mais jamais affichés, d'où un 403 partiel. Correction : filtrer les cibles avant la boucle.
11. L'administration Django et le garde `UserProfile.save` :
    - `ADMIN_NAVIRE` reste dans `Roles.choices`, donc `UserProfileAdmin` et `RoleAvailability` le proposent. Le choisir donne un 500 `ValueError`.
    - `update()`, `bulk_create` et `loaddata` contournent `save` : une ligne obsolète reste possible. Elle tombe au niveau équipier sans drapeau, donc fermée, sans élévation.
    - Corrections : filtrer les choix dans le `ModelForm`, ajouter `administrateur_technique` à `list_display` et `list_filter`, envisager un `CheckConstraint` après migration.
    - Le drapeau n'a aucune interface web : il n'est attribuable que par API ou Django admin, donc l'ergonomie d'installation manque. C'est le sujet de la proposition d'initialisation.
12. Commentaires et documentation :
    - `training/web_views.py:60-68` et `:196` : bloc orphelin, constante `NIVEAU_REQUIS_CREATION_FORMATION` supprimée mais encore citée (« INCHANGÉ »). Idem `training/tests/test_creation_formation.py:4`.
    - `matrix/core/scopes.py:211` : « administrateur d'unité ».
    - `matrix/core/permissions.py:20`, `matrix/views.py:276`, `matrix/core/mixins.py:71` : commentaires périmés.
    - `docs/recette/L06_MIGRATION_ET_PREUVES.md` est non suivi (`git status`) et garde les marqueurs `__RESULTATS__` / `__RELECTURES__`.
    - Le commentaire de `seed_demo` est correct. Le bloc de commentaire multi-lignes de `ManageUsersPermission` dépasse « court », mais c'est un docstring.
13. Test flaky (`test_poste_vacant_visible_sans_relève_interne`) : aucun lien avec L06. Le seed ne change que l'administrateur démo, qui devient équipier + technique. Le test mélange `timezone.localdate()` (`self.jour`, Paris) et `debut__date`, comparée dans le fuseau de la base. Entre minuit Paris et minuit UTC (donc surtout 00:00-02:00 Paris l'été, 00:00-01:00 l'hiver), la date calculée diffère, d'où l'échec ponctuel. À traiter dans un autre lot.

## Tests

- Les adaptations suivent la règle du lot (administrateur → commandant ou technique) et je n'en vois aucune qui affaiblisse une protection. Quelques-unes déplacent la couverture :
  - `matrix/tests/test_securite_terre_second.py` : l'échelle de rôles exclut `ADMIN_NAVIRE` et le seuil du catalogue devient `MASTER_ADMIN`. Le droit technique n'y est plus exercé dans la matrice, seulement dans `training/tests/test_creation_formation.py`.
  - `accounts/tests/test_matrice_droits.py` : `admin_a`→équipier passe de 200 à 403 sans qu'aucun test ne couvre le PATCH sans `role` (le cas qui permet les failles 1 à 3).
  - `matrix/tests/test_modules_activables.py` : `ACTION` passe de `module_gestion` à `poste_gestion` (justifié par le plancher), `ETAT_MAJOR` remplace `CHEF_SERVICE` dans une boucle de seuils.
  - `chef_section_a` devient `COMMANDANT` à la place d'`ADMIN_NAVIRE` dans quelques tests (`org/tests`, `quarts/tests`) : le scénario n'est plus « administrateur » mais commandant. Le test reste valide en périmètre.
- Manques à ajouter : technique + `fonction_coma` (soi et tiers), technique + `allowed_sectors` ou rattachement sur soi, `PUT` multipart sans drapeau, audit du changement du drapeau, `bulk_reset` avec une cible non réinitialisable, `ADMIN_NAVIRE` via l'administration Django.
- `test_l06_migration.py` est un `TransactionTestCase` correct et il restaure l'état final (`tearDown`). Il ne couvre ni un rôle modifié après migration avant retour arrière, ni l'idempotence (double application). L'`AlterField` ne génère aucun SQL, donc pas de problème SQLite/PostgreSQL attendu. La doc dit que la procédure a été rejouée sur PostgreSQL 16 : non revérifié ici.

## Changements observables par rôle (justifiés ou non)

- **Commandant** :
  - Gagne : modifier la structure de l'unité, archiver, double équipage, fuseau, types de programme. Ces actes passent du niveau 8 au plancher COMMANDANT, justifié par AC-02 (`structure_navire_ecriture`, `unite_administration`, `programme_types`).
  - Garde : l'activation des modules (plancher COMMANDANT).
  - Perd : il ne modifie plus un compte technique dans l'annuaire web. Il ne réinitialise pas les mots de passe (seuil technique, comme avant). Il ne désigne plus personne en commandant ou second : seul l'administrateur général le peut. C'est la question 3 de la proposition, à trancher.
- **Commandant en second** : ne peut plus activer un module (voulu, `module_gestion` = COMMANDANT). Garde la lecture annuaire et délais. Sa désignation et celle du commandant ne relèvent que du MASTER (régression assumée dans la doc).
- **État-major** : ne désigne plus les chefs de service (voulu, AC-02). Garde chefs de secteur, de section et équipiers.
- **Chefs de service, de secteur, de section, équipier** : inchangés, hors cas où ils étaient « ADMIN_NAVIRE ».
- **Administrateur technique seul** :
  - Perd tout droit métier : publier, viser, valider, tickets, passation, COMANAV, délais, relève et onglet Équipage, structure, modules, types de programme.
  - Garde ou obtient : les seuils (dans les planchers, mais voir point 5), la réinitialisation des mots de passe d'un compte non technique jusqu'à chef de section, la création de formation, le styleguide, l'annuaire en lecture, et l'API d'édition de profil (sans changer le rôle).
  - Non justifié : modifier `fonction_coma` et le rattachement de comptes autorités (points 1 et 2).
- **Cumul commandant + technique** : conserve les deux jeux de droits. Il est exposé aux mêmes points si le contrôle de champs manque.
- **MASTER_ADMIN / superutilisateur** : inchangés (hors périmètre), sauf le point 9.
- **Compte sans profil, inactif, `ADMIN_NAVIRE` résiduel** : aucun droit (équipier, ou pas de drapeau). Fermeture correcte.
- **Pages concernées** : `directory.html` (boutons masqués selon `peut_gerer_metier`), onglet Équipage (réservé aux commandant et second), tableau COMANAV (plus d'ADMIN_NAVIRE), délais d'activation (le second reste en lecture), création de formation par l'API (technique seulement, commandant exclu comme avant).
