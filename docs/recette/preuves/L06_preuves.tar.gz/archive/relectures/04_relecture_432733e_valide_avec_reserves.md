# Relecture 4 — état 432733e — verdict VALIDE AVEC RÉSERVES

(Rapport du relecteur indépendant, repris tel que remis ; corrections des points importants dans e004ee6.)

RAPPORT DE RELECTURE L06 (branche claude/l06-autorites-technique-metier-v11, SHA 432733e, tout le lot c355310..432733e)

Relecture en lecture seule. Sondes réelles avec une base SQLite temporaire sous /tmp/relecture_l06d (tests Django jetables, shell, migrations avant/arrière). Je n'ai pas lancé la suite complète. Je n'ai pas touché à PostgreSQL : ce que je dis de PostgreSQL vient de la lecture du code, sans exécution.
Tests existants rejoués : matrix.tests.habilitation, accounts.tests.test_reinitialisation_ac12 et test_matrice_droits, 117 tests, tous OK avec --parallel 2.

VERDICT : VALIDE AVEC RÉSERVES
- Aucune élévation de privilège métier directe n'a été trouvée.
- Deux défauts de code (I-1, I-2) méritent une correction avant clôture. Ils sont petits.
- Le point I-3 demande une décision du PO, ou un correctif.
- Le point I-4 est un défaut de livraison : des documents modifiés ne sont pas commités.

BLOQUANTS : aucun.

IMPORTANTS

I-1. `mot_de_passe_provisoire_expire_le` est modifiable par l'API des profils (contournement de la validité limitée, AC-12).
- Fichier : accounts/serializers.py:20. `read_only_fields` ne contient que `administrateur_technique` et `mot_de_passe_provisoire`, alors que `fields = "__all__"`.
- Scénario sondé :
  - Un administrateur technique réinitialise le mot de passe d'un équipier.
  - Il envoie ensuite PATCH /api/accounts/profiles/<id>/ avec `{"mot_de_passe_provisoire_expire_le": "2099-01-01T00:00:00Z"}`.
  - La réponse est 200 et la date est enregistrée. Le mot de passe provisoire ne s'éteint plus.
  - Aucune trace n'est écrite dans l'AuditLog.
- Même voie pour tout profil modifiable : un chef peut aussi avancer la date dans le passé, ce qui bloque le marin.
- Correctif : ajouter le champ à `read_only_fields`, avec un test.

I-2. La commande `recuperer_acces_administrateur` ne lève pas le verrouillage de connexion, et le verrouillage est local à chaque processus.
- Fichiers : accounts/management/commands/recuperer_acces_administrateur.py:44 et accounts/authentification.py.
- `settings.py` n'a pas de `CACHES` : le backend par défaut est LocMemCache, propre à chaque processus.
- Vérifié : une clé posée dans un processus est `None` dans un autre processus.
- Conséquences :
  - La commande, lancée dans son propre processus, ne débloque pas le serveur. Le docstring ("efface le verrouillage") est faux. Un administrateur général verrouillé reste bloqué jusqu'à 15 minutes ou jusqu'au redémarrage.
  - Avec plusieurs processus serveur, le plafond réel est de 5 essais par processus. Un redémarrage remet le compteur à zéro.
  - Le compteur (lecture puis écriture, lignes 24-26) n'est pas atomique.
- Correctif : compteur en base ou cache partagé (`DatabaseCache` ou fichier, sans service externe), `cache.incr` atomique, ou à défaut un document honnête.
- Question de conception à noter : le verrouillage par identifiant permet à n'importe qui de bloquer 15 minutes le commandant ou un administrateur connu. À consigner dans les risques acceptés.

I-3. Un administrateur technique peut retirer les droits techniques d'un pair, puis réinitialiser son mot de passe. Cela contourne AC-12 et l'esprit d'AC-11.
- Fichiers : accounts/web_views.py:610 (`set_technique`), accounts/views.py (PATCH `administrateur_technique`) et accounts/services.py (`niveaux_de_protection`).
- Sondé en web et en API : un technique retire le drapeau à un autre technique (200 en API), puis `set_password` sur ce compte réussit et renvoie un mot de passe provisoire.
- Cela contredit AC-12 (un technique ne réinitialise que équipier à chef de service) et AC-11 (gestion des administrateurs techniques réservée à l'administrateur général).
- Pas d'élévation en soi, mais un technique malveillant peut supprimer ses collègues, puis s'approprier leurs comptes.
- Le point est déjà posé au PO (§13 question 5), mais pas la chaîne retrait puis réinitialisation.
- Correctif proposé : retrait ou attribution des droits techniques d'un compte déjà technique réservés à l'administrateur général, en web et en API.
- À défaut : décision explicite du PO, et faire apparaître la chaîne dans la question.

I-4. Documents du lot non commités sur le SHA relu.
- `git status` : docs/REFERENCE.md, docs/recette/L06_MIGRATION_ET_PREUVES.md et docs/recette/L06_PROPOSITION_INITIALISATION.md sont modifiés et non commités.
- La version commitée de L06_MIGRATION_ET_PREUVES.md est l'ancienne : elle s'arrête au §11, renvoie à `326387b` et dit "aucun outil de confirmation n'est livré". Elle n'a pas les §12 (frontière de confiance) ni §13 (questions au PO) que DECISIONS_PO.md invoque pour AC-11.
- À commiter avant clôture.

MINEURS

- Valeur de `decision` non validée.
  - accounts/fonctions.py:55-56 : toute valeur autre que "confirmer" ou "refuser", par exemple "xyz" ou "", est traitée comme une correction.
  - Sondé : l'audit écrit `fonction_a_confirmer_xyz`, et `anomalies_de_coherence()` signale ensuite "Décision sans trace d'audit".
  - Correctif : refuser toute décision hors CONFIRMER, CORRIGER et REFUSER.
- Commandant sans bâtiment.
  - accounts/fonctions.py (`demandes_visibles_par`) : `ship_id=None` correspond aux demandes sans bâtiment.
  - Sondé : un commandant dont `ship` est vide confirme une demande sans bâtiment, qui devient ÉTAT-MAJOR sans bâtiment.
  - Cas marginal. Correctif : exiger un bâtiment pour décider.
- Cumul implicite à l'initialisation.
  - accounts/management/commands/initialiser_autorites_batiment.py:63 : le contrôle ne porte que sur `technique is None`.
  - Sondé : un compte déjà technique désigné commandant avec `--administrateur-technique autre` garde ses droits techniques sans `--accepter-cumul`. AC-09 dit "jamais automatique".
- Mots de passe provisoires antérieurs à 0025.
  - Sondé : un compte avec `mot_de_passe_provisoire=True` et expiration vide se connecte indéfiniment.
  - La migration 0025 ne remplit pas la date. Correctif : expiration dans la migration, ou traiter une expiration vide comme expirée.
- "Usage unique" au sens large.
  - Le mot de passe provisoire ouvre autant de sessions que l'on veut jusqu'au changement ou à l'expiration (sondé : deux connexions réussies).
  - Seul le changement obligatoire (middleware, 403 API vérifié) le limite. C'est acceptable. À le dire dans la recette.
- Tests creux ou faibles.
  - matrix/tests/habilitation/test_l06_autorites.py:128 : `test_un_envoi_multipart_ne_retire_pas_le_drapeau_technique` envoie un PUT sur le profil d'`equipier_b1`, puis vérifie le drapeau de l'acteur `admin_navire`. Il est vert quoi qu'il arrive.
  - accounts/tests/test_initialisation_et_recuperation.py : `test_usage_unique_par_batiment` ne prouve pas la contrainte d'unicité. Le refus vient du contrôle "commandant existant". J'ai vérifié à la main : après désactivation du commandant, la ré-initialisation est bien refusée par la contrainte, mais aucun test ne le couvre.
  - matrix/tests/habilitation/test_l06_migration.py:8 : `APRES = 0025`, alors que 0026 existe. Le test laisse le schéma sans la table `InitialisationBatiment`. Sans effet ici, fragile.
- Code mort.
  - `porte_une_designation` (accounts/services.py:44) n'est appelée nulle part.
  - `statuts_d_administration` n'est utilisée que par des tests : l'AC-11 existe donc comme classification, sans comportement.
  - `anomalies_de_coherence` n'est appelée que par des tests : aucun contrôle d'exécution pour AC-14.
- Retour arrière 0024.
  - Si une fonction a été confirmée (rôle ÉTAT-MAJOR), la restauration ne correspond plus à `role=apres` : le compte n'est pas restauré et sa ligne de journal est quand même supprimée.
  - Cohérent avec la condition documentée "rôle modifié non écrasé", mais l'information est perdue.
- `set_technique` côté web : `cible.profile` plante (500) pour un compte sans profil quand l'acteur est l'administrateur général (filtre `Q()`).
- Administration Django.
  - Un staff qui a `change_userprofile` peut attribuer MASTER_ADMIN ou le second sans les règles d'AC-10, avec audit rôle et technique seulement (`allowed_sectors` non audité).
  - C'est la frontière de confiance documentée. À conserver dans les mesures d'exploitation.
- Catalogue de formations (training/views.py `CatalogueFormationPermission` et `_exiger_catalogue`) : tout administrateur technique de bâtiment écrit le catalogue commun à toute la flotte.
  - Comportement hérité de l'ancien ADMIN_NAVIRE.
  - À confirmer au regard de "aucun droit métier" (AC-11).
- Risque accepté par AC-12, à rappeler au PO : un technique obtient l'autorité complète d'un chef de service en réinitialisant son compte. Les garde-fous sont la trace d'audit et la notification au titulaire.

POINTS VÉRIFIÉS (sondés)

- Migrations 0024, 0025 et 0026, SQLite.
  - Base à 0023 avec 4 ADMIN_NAVIRE (dont un sans bâtiment, deux avec la même fonction) et un commandant. Passage en avant : tous deviennent ÉQUIPIER + technique, le commandant est inchangé. Fonction retirée de la fiche, 4 lignes d'audit, 3 demandes EN_ATTENTE.
  - Retour arrière jusqu'à 0023 : rôles et fonctions restaurés, journal vide. Ré-application OK.
  - `makemigrations --check` : aucun changement en attente.
  - PostgreSQL non exécuté. Lecture du code : contrainte unique partielle valide, `select_for_update(of=("self",))` correct malgré les jointures externes.
- Initialisation (AC-09).
  - Refus vérifiés : autorisation vide, cumul sans option, administrateur général, autre bâtiment, technique avec autorité, deuxième exécution.
  - Après désactivation du commandant, la ré-initialisation est refusée par la contrainte d'unicité.
  - Audit sans secret.
  - Verrouillage concurrent par `select_for_update` plus unicité en base (PostgreSQL : lecture du code).
  - Aucun mot de passe créé.
- Récupération.
  - Refusée pour un non administrateur général.
  - Mot de passe affiché une fois, absent de l'audit, valide jusqu'à l'expiration, sessions précédentes invalidées.
- Réinitialisation (AC-12), web.
  - Technique : équipier à chef de service OK ; refusé pour ÉTAT-MAJOR, second, commandant, autre technique, administrateur général, compte staff, autre bâtiment, compte sans bâtiment.
  - Commandant et second : 403.
  - Réinitialisation de masse : seuls les comptes de niveau technique sont traités.
  - Effets : session ouverte invalidée, notification "securite" créée, audit sans mot de passe, Cache-Control no-store.
  - Expiration refusée à la connexion, session et API Basic bloquées par le middleware tant que le mot de passe n'est pas changé.
  - Le changement efface le drapeau et l'expiration.
  - Verrouillage : 5 mauvais essais refusent aussi le bon mot de passe, sans toucher un autre compte.
- API et web des profils.
  - 403 pour un technique qui change rôle, fonction, bâtiment ou secteurs.
  - Self-modification refusée.
  - Le commandant désigne et révoque le second (200).
  - Second, ÉTAT-MAJOR, technique ne désignent pas.
  - Un non-technique ne peut pas poser `administrateur_technique`.
  - Rôle `ADMIN_NAVIRE` refusé (403 et 400).
  - Actions web interdites au technique (create_user, edit_user, delete_user, bulk_*) : 403.
  - Suppression de comptes techniques réservée à l'administrateur général.
  - `set_technique` refusé aux non-techniques, à soi-même, à l'administrateur général, hors bâtiment.
- Seuils (AC-13), planchers (AC-02) : relus et couverts par les tests habilitation rejoués. Le technique ne modifie aucun seuil métier (403), planchers non abaissables.
- Fonctions à confirmer (AC-14).
  - Refusées : soi-même, autre bâtiment, second, technique.
  - Confirmer sur un compte porteur d'une autorité supérieure ou une fonction déjà tenue : refus avec message.
  - L'administrateur général décide pour un autre bâtiment.
  - Vues : GET 403 pour un technique, 200 pour le commandant.
- Commentaires obsolètes : plus de `ADMIN_NAVIRE` dans le code applicatif hors modèle, migration, seuils techniques et `roles.py`.
