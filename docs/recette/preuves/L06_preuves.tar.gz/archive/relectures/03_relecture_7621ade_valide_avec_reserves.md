# Relecture 3 — état 7621ade — verdict VALIDE AVEC RÉSERVES

(Rapport du relecteur indépendant, repris tel que remis.)

RELECTURE L06 (HEAD 7621ade contre c355310), lecture seule. Sondes dans /tmp/relecture_l06c, base SQLite temporaire, rien modifié dans le dépôt.

VERDICT : VALIDE AVEC RÉSERVES. Aucun bloquant. Tous les points B1, I1 à I4, M1, M4 et M7 de la seconde relecture sont réellement corrigés. Je n'ai trouvé aucune élévation de privilège de niveau métier par un technique. Je demande une correction avant fusion (I-A, un compte réinitialisable qui ouvre la voie à l'administration Django) et plusieurs mineurs.

BLOQUANTS : aucun.

IMPORTANTS

I-A. Un technique peut réinitialiser le mot de passe d'un compte `is_staff`. Fichier : accounts/services.py:36-44 (`_reinitialisable_par_technique`).
- Le garde-fou exclut `is_superuser`, les techniques, `fonction_coma`, les désignations et les rôles au-dessus de chef de section. Il ne regarde ni `is_staff`, ni les groupes, ni les `user_permissions` Django.
- Sonde : `admin_navire` (technique, équipier) POST `/users/` `action=set_password` sur `staff_sans_droit` (`is_staff`, équipier) donne 200 et une page de mot de passe provisoire.
- Scénario : un compte staff qui détient les droits Django sur `UserProfile` peut, depuis /admin/, se donner `role=COMMANDANT` ou `administrateur_technique`. Le technique reprend donc ce compte et obtient une autorité métier. Le contrôle contourne ce que le lot cherche à interdire (AC-01).
- Correctif : ajouter `not cible.is_staff` et `not cible.user_permissions.exists()` / `not cible.groups.exists()` dans `_reinitialisable_par_technique`. Ajouter un test.

MINEURS

M-A. Un technique modifie des champs personnels ou d'identité sur n'importe quel compte du bâtiment (API des profils). Fichier : matrix/core/permissions.py:107-146 et accounts/serializers.py:15-20. Seuls les champs listés dans `CHAMPS_AUTORITE` sont gardés.
- Sonde : le technique PATCH sur le commandant `cdt_a` avec `mot_de_passe_provisoire=True`, `matricule` et `theme` donne 200. Le compte du commandant est forcé en changement de mot de passe, et son matricule est écrasé sans autre contrôle.
- C'est du harcèlement ou de la falsification, pas de l'élévation.
- Correctif : donner au technique une liste blanche de champs (grade, spécialité, matricule, notification), ou retirer `mot_de_passe_provisoire` du sérialiseur (il est déjà géré par le service de réinitialisation).

M-B. La fonction de commandant adjoint journalisée « à confirmer » reste sur la fiche et s'active sans confirmation. Fichiers : accounts/migrations/0024_administrateur_technique.py:19-27 et accounts/views.py:57-66.
- Après migration, un ancien administrateur est équipier avec `fonction_coma="COMAEQ"`. Cette valeur ne produit aucun effet tant que le rôle n'est pas état-major (`est_titulaire` exige `ETAT_MAJOR`).
- Sonde : un commandant fait un PATCH `{"role":"ETAT_MAJOR"}` sur un équipier qui porte `fonction_coma=COMAEQ`. Réponse 200, `est_titulaire(...)=True`. `fonction_coma` n'est pas envoyée donc n'est pas dans `modifies`. La fonction s'active à la simple promotion, sans que le commandant la voie ni la confirme (AC-01).
- Correctif : soit mettre `fonction_coma=''` dans la migration (la valeur est déjà dans le journal), soit exiger, quand le rôle devient `ETAT_MAJOR`, que la fonction soit renvoyée explicitement ou remise à vide.

M-C. Traçabilité du Django admin incomplète. Fichier : accounts/admin.py:11-19.
- Sonde : un superutilisateur modifie le rôle et le drapeau. Le journal contient « role modifié par l'administration Django », sans valeurs avant/après.
- La création d'un profil (`change=False`) n'est pas auditée alors qu'elle peut poser rôle et drapeau.
- Correctif : utiliser `form.initial` pour écrire `avant -> après`, et auditer aussi la création.

M-D. Incohérence entre l'interface web et le serveur, et coût de la vérification. Fichiers : accounts/web_views.py:90-91,194-197,598 et accounts/services.py:47-56.
- `gerables_ids` propose « Réinitialiser » sur un chef de section porteur d'une désignation ou d'un `fonction_coma`. Le clic donne une page 403 brute (`PermissionDenied` levée dans `reinitialiser_mot_de_passe`), et non un message.
- Le droit est défini deux fois : tuple de rôles dans le web, comparaison de niveaux dans les services.
- `porte_une_designation` fait 10 requêtes par cible, soit environ 1000 pour une réinitialisation de masse de 100 comptes.
- Correctif : calculer la liste réinitialisable une fois (un `Exists` par désignation) et afficher un message au lieu du 403.

M-E. La suppression du palier laisse des sorties silencieuses. Fichier : matrix/core/role_thresholds.py:278.
- Un seuil technique abaissé par un technique (par exemple `mot_de_passe_reinitialisation` à EQUIPIER, sondé : accepté) est correctement autorisé. Il donne `peut_reinitialiser=True` à des rôles qui ne passent pas la garde web. Pas d'impact exploitable, mais le libellé de l'onglet « Sécurité » ne le dit pas.
- Les comptes techniques restent visibles de l'API pour un commandant (le web les masque). Un commandant peut changer le rôle d'un technique via l'API (sondé : 200). C'est signalé dans la doc §11, il reste à aligner.

M-F. Tests. matrix/tests/habilitation/test_l06_autorites.py, `test_un_compte_porteur_d_une_designation_n_est_pas_reinitialisable_par_un_technique`.
- Le test vérifie seulement `hasattr(User, relation)`. Il ne détecte pas une nouvelle relation d'autorité oubliée dans `DESIGNATIONS`.
- Aujourd'hui la liste est complète (voir points vérifiés), mais rien ne le garantit à l'avenir.
- Correctif : un test qui énumère `User._meta.related_objects` et exige que chaque relation soit soit dans `DESIGNATIONS`, soit dans une liste d'exclusion justifiée.
- Le test de migration ne couvre pas un administrateur avec `is_staff` ni un seuil stocké à `ADMIN_NAVIRE` (couvert par un test séparé, correct).

POINTS VÉRIFIÉS (sondes réelles)

Corrections de la seconde relecture
- B1 : un technique sans commandement (équipier + drapeau) POST `update_role_threshold` sur `liste_service_publication` à EQUIPIER : refusé, seuil inchangé (effectif CHEF_SERVICE). Même refus sur `reset_role_threshold` quand le défaut est inférieur au seuil courant. Renforcer (COMMANDANT) et réinitialiser vers un défaut plus fort sont acceptés. Un commandant avec drapeau (`cdt_admin`) peut abaisser, comme prévu. `_abaisse_sans_autorite_metier` couvre les deux branches (matrix/views.py:871-890). Le test `SeuilsTechniqueTests` couvre `liste_service_publication`, `feuille_service_visa_service`, `alerte_organisation_validation`.
- Autres voies de modification de seuils : seul matrix/views.py écrit `thresholds`. `module_gestion`, `structure_navire_ecriture`, `unite_administration` et `programme_types` ont un plancher COMMANDANT appliqué à la lecture par `seuil_role` (une base écrite hors vue reste écrêtée).
- I1 : les 10 relations de `DESIGNATIONS` couvrent toutes les relations d'autorité de `User._meta.related_objects` (j'ai énuméré les relations à partir du modèle). Sondes de réinitialisation par le technique : refusé sur chef de secteur, état-major, commandant, second, technique, administrateur général, autre navire. Accepté sur équipier et chef de section. Lors de la réinitialisation de masse, les cibles non éligibles sont ignorées.
- I2 : migration sans promotion. Sonde sur base SQLite construite à 0023 : `adm1` et `adm2` (avec `COMAEQ`) deviennent EQUIPIER + drapeau ; commandant et équipier intacts ; 2 lignes d'audit `l06_migration_role`, fonction journalisée.
- Retour arrière : `migrate accounts 0023` restaure `ADMIN_NAVIRE` pour `adm2`, ne touche pas `adm1` dont le rôle a changé entre-temps, supprime les lignes d'audit. `makemigrations --check` : aucun changement. La procédure PostgreSQL n'a pas pu être rejouée ici (pas de PostgreSQL). Lecture du code : DDL avant les `UPDATE` en avant, `UPDATE` puis `DROP COLUMN` en arrière sur la même table sans changement de clé étrangère, ce qui ne doit pas poser le problème de déclencheurs différés. À confirmer sur PostgreSQL 16 par le preuve jointe.
- I3 : un seuil stocké à `ADMIN_NAVIRE` sur une action métier est écrêté à COMMANDANT (sondé, effectif COMMANDANT) ; le technique peut remettre COMMANDANT sans que ce soit un abaissement.
- I4 : `test_l06_autorites.py` est maintenant réel (API, Sécurité, audit, drapeau multipart). Le test de drapeau vérifie bien les 403, les traces d'audit et l'absence de retrait par multipart.
- M1 : le technique d'un autre navire reçoit 404 (queryset) ; le technique sans navire ne voit aucun profil (liste 0, PATCH 404). Double garde par comparaison de navire dans `has_object_permission`.
- M4 : Django admin : modification du rôle et du drapeau par un superutilisateur auditée (2 lignes `changement_role` et `changement_droits_techniques`) ; la valeur `ADMIN_NAVIRE` est refusée par le formulaire.
- M7 : un non-maître ne peut pas dépasser COMMANDANT pour un seuil métier ni ADMIN_NAVIRE pour un seuil technique (`structure` à ADMIN_NAVIRE par un commandant : refus). Les seuils globaux restent réservés à l'administrateur général.

Nouveaux contrôles (aucun défaut)
- API profils : le technique ne peut ni envoyer `role`, `fonction_coma`, `ship`, `service`, `sector`, `section`, `allowed_sectors` ou `equipage` (403, y compris `role` identique), ni changer son propre drapeau ou rôle (403). Un drapeau invalide ou nul donne 400 avant sauvegarde. Un commandant ne peut ni poser le drapeau (403), ni désigner le second, ni changer le rôle d'un état-major vers chef de service. L'état-major ne désigne plus les chefs de service (403, voulu par AC-02). Le commandant désigne une fonction `COMAEQ` sur un état-major : 200, audité. Le chef de service ne s'élève pas lui-même (403).
- Web annuaire : le technique obtient 403 sur `edit_user`, `bulk_update_role`, `create_user`, `bulk_delete_users` et `delete_user`. Il garde `set_password` et `bulk_reset_passwords`. Le commandant ne réinitialise pas (seuil technique par défaut). Le commandant ne voit ni ne reprend un compte technique dans le web.
- Architecture : pas de système parallèle. L'indicateur étend `RoleLevel` et le registre de seuils (`ActionSeuil.plancher`, `ActionSeuil.technique`) et réutilise le socle L29. `RoleLevel.ADMIN_NAVIRE` ne sert plus que de palier technique, documenté. `UserProfile.save()` refuse l'ancien rôle ; aucune occurrence active hors commentaires.
- Tests ciblés lancés : `matrix.tests.habilitation` (71 tests) OK ; `accounts` (168 tests, 1 ignoré) OK avec `--parallel 2`. Suite complète non lancée, comme demandé.
