import os, sys, django, json
sys.path.insert(0, os.getcwd())
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "matrix.settings")
django.setup()
from accounts.models import FonctionAConfirmer, AuditLog
from accounts import fonctions
print(json.dumps({"demandes": [[d.user.username, d.fonction_ancienne, d.statut] for d in FonctionAConfirmer.objects.order_by("user__username")],
 "journal_l06": AuditLog.objects.filter(action="l06_migration_role").count(), "anomalies_coherence": fonctions.anomalies_de_coherence()}, sort_keys=True))
