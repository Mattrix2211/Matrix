import os, sys, django, json
sys.path.insert(0, os.getcwd())
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "matrix.settings")
django.setup()
from accounts.models import UserProfile, AuditLog
champs = ("role", "administrateur_technique")
etat = {}
for p in UserProfile.objects.select_related("user").order_by("user__username"):
    etat[p.user.username] = [p.role, getattr(p, "administrateur_technique", None), p.fonction_coma]
print(json.dumps({"profils": etat, "journal": AuditLog.objects.filter(action="l06_migration_role").count(), "total": UserProfile.objects.count()}, sort_keys=True))
