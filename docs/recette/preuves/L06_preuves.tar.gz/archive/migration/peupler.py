"""Données FICTIVES : comptes de tous rôles dont des administrateurs d'unité (état L29), pour la migration L06."""
import os, sys, django
sys.path.insert(0, os.getcwd())
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "matrix.settings")
django.setup()
from django.contrib.auth import get_user_model
from accounts.models import UserProfile
from org.models import Ship, Service, Sector
U = get_user_model()
nav = Ship.objects.create(name="Bâtiment fictif", code="FIC")
svc = Service.objects.create(ship=nav, name="Service fictif", commandant_adjoint="COMANAV")
sec = Sector.objects.create(service=svc, name="Secteur fictif")
def compte(nom, role, fonction="", **kw):
    u = U.objects.create_user(nom, password=os.urandom(8).hex())
    UserProfile.objects.update_or_create(user=u, defaults={"role": role, "fonction_coma": fonction, "ship": nav, "service": svc, "sector": sec, **kw})
for nom, role, fonction in [
    ("adm_seul", "ADMIN_NAVIRE", ""), ("adm_coma", "ADMIN_NAVIRE", "COMANAV"), ("adm_inconnu", "ADMIN_NAVIRE", ""),
    ("cdt", "COMMANDANT", ""), ("second", "COMMANDANT_EN_SECOND", ""), ("coma", "ETAT_MAJOR", "COMOPS"),
    ("chef_service", "CHEF_SERVICE", ""), ("chef_secteur", "CHEF_SECTEUR", ""), ("chef_section", "CHEF_SECTION", ""),
    ("marin1", "EQUIPIER", ""), ("marin2", "EQUIPIER", ""),
]:
    compte(nom, role, fonction)
print("comptes:", U.objects.count())
